const submitBtn = document.getElementById("maakAcc");
submitBtn.addEventListener("click", function() {
    // prevent the form from submitting

    // Get form values
    var naam = document.getElementById("naam").value;
    var voorNaam = document.getElementById("voornaam").value;
    var telefoon = document.getElementById("tel").value;
    var postCode = document.getElementById("post").value;
    var gemeente = document.getElementById("gemeente").value;
    var adres1 = document.getElementById("adres1").value;
    var adres2 = document.getElementById("adres2").value;


    // Create object with form values
    var formData = {
        "AchterNaam": naam,
        "VoorNaam": voorNaam,
        "TelefoonNummer": telefoon,
        "Postcode": postCode,
        "Gemeente": gemeente,
        "AdresRegel1": adres1,
        "AdresRegel2": adres2
    };

    // Convert object to JSON string
    var formDataJson = JSON.stringify(formData);

    // Log JSON string to console
    console.log(formDataJson);
});