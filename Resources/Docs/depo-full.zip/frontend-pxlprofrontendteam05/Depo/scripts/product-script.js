//Global variables
let productData;
let priceData;
let productAvailability;
let listImages = [];
let currentImageIndex = 0;
let selectedSize = null;
let processContainers = [];
let processStep = 0;
let navDots = [];

//let loadingIndicator; //Loading indicator
//let errorMessage; //Error message
let dateElement; //Date element


//On page load | Page build up
window.addEventListener('DOMContentLoaded', () => {
    //Get productData & Availability from sessionStorage
    productData = JSON.parse(sessionStorage.getItem('productData'));
    listImages = productData.ListImageNames;

    //Assign process containers and nav dots
    processContainers = document.getElementsByClassName('process-container');
    navDots = document.getElementsByClassName('nav-dot');

    //If productAvailability is empty, fetch it from the server
    if (!sessionStorage.getItem('productAvailability')) {
        assignProductAvailability().then(() => {
            buildProductPage();
        });
    } else {
        productAvailability = JSON.parse(sessionStorage.getItem('productAvailability'));
        buildProductPage();
    }
});

async function assignProductAvailability() {
    productAvailability = await fetchProductAvailability(productData.LocatieId);
}

async function buildProductPage() {
    //Gemeente
    document.getElementsByClassName('product-title')[0].innerHTML = `Garagepark in ${productData.Gemeente}`;
    document.title = `Garagepark in ${productData.Gemeente}`;

    //Product Image
    document.getElementById('current-img').src = `/frontend-pxlprofrontendteam05/Depo/product-img/${listImages[currentImageIndex]}.jpg`;
    document.getElementById('current-img-big').src = `/frontend-pxlprofrontendteam05/Depo/product-img/${listImages[currentImageIndex]}.jpg`;

    //get selected size
    selectedSize = getSelectedSize();

    //Afmetingen
    let sizes = createSizeElement();
    let sizeContainer = document.getElementsByClassName('size-container')[0];
    sizes.forEach((size) => {
        //Add the size to the container
        sizeContainer.appendChild(size);
    });

    //Set selected size if it exists
    if (selectedSize) {
        setSelectedSize(selectedSize);
        setProductOmschrijving(selectedSize);
    } else {
        document.getElementsByClassName('product-availability')[0].innerHTML = 'Selecteer een formaat';
    }

    //Beschikbaarheid
    updateAvailability();

    //Prijzen
    if (selectedSize != null) {
        await buildPriceElements();
    }

    //datum element
    dateElement = document.getElementById('datumElement');
    updateDateProperties();

    //Process containers
    adjustProcessContainersSize();
}

async function buildPriceElements() {
    //Get priceData
    priceData = await filterPriceData(await fetchPrices());

    //Update priceData with total price and BTW
    priceData = updatePriceData(priceData);

    //The containers
    let maandelijkseContainer = document.getElementsByClassName('prijs-lijst')[0];
    let eenmaligeContainer = document.getElementsByClassName('prijs-lijst')[1];

    //Clear the containers except the first child element
    while (maandelijkseContainer.children.length > 1) {
        maandelijkseContainer.removeChild(maandelijkseContainer.lastChild);
    }
    while (eenmaligeContainer.children.length > 1) {
        eenmaligeContainer.removeChild(eenmaligeContainer.lastChild);
    }

    //Add total prices first
    let maandelijksTotaalElement = document.createElement('p');
    maandelijksTotaalElement.classList.add('totaal-p');
    maandelijksTotaalElement.textContent = `€${priceData.MaandelijksTotaal.toFixed(2)}`;
    maandelijkseContainer.appendChild(maandelijksTotaalElement);

    let eenmaligTotaalElement = document.createElement('p');
    eenmaligTotaalElement.textContent = `€${priceData.EenmaligTotaal.toFixed(2)}`;
    eenmaligTotaalElement.classList.add('totaal-p');
    eenmaligeContainer.appendChild(eenmaligTotaalElement);

    //Create other price elements & add it to the container
    let huurElementText = document.createElement('p');
    let huurElementValue = document.createElement('p');
    huurElementText.style.display = 'none';
    huurElementValue.style.display = 'none';
    huurElementText.textContent = 'Huurprijs:';
    huurElementValue.textContent = `€${priceData.Huurprijs.toFixed(2)}`;


    let serviceElement = document.createElement('p');
    let serviceElementText = document.createElement('p');
    serviceElement.style.display = 'none';
    serviceElementText.style.display = 'none';
    serviceElement.textContent = `€${priceData.ServiceKosten.toFixed(2)}`;
    serviceElementText.textContent = 'Servicekosten:';


    let energieElement = document.createElement('p');
    let energieElementText = document.createElement('p');
    energieElement.style.display = 'none';
    energieElementText.style.display = 'none';
    energieElement.textContent = `€${priceData.EnergieKosten.toFixed(2)}`;
    energieElementText.textContent = 'Energiekosten:';

    let waarborgElement = document.createElement('p');
    let waarborgElementText = document.createElement('p');
    waarborgElement.style.display = 'none';
    waarborgElementText.style.display = 'none';
    waarborgElement.textContent = `€${priceData.Waarborg.toFixed(2)}`;
    waarborgElementText.textContent = 'Waarborg:';

    let administratieElement = document.createElement('p');
    let administratieElementText = document.createElement('p');
    administratieElement.style.display = 'none';
    administratieElementText.style.display = 'none';
    administratieElement.textContent = `€${priceData.AdministratieKosten.toFixed(2)}`;
    administratieElementText.textContent = 'Administratiekosten:';

    let regionaleElement = document.createElement('p');
    let regionaleElementText = document.createElement('p');
    regionaleElement.style.display = 'none';
    regionaleElementText.style.display = 'none';
    regionaleElement.textContent = `€${priceData.RegionalePrijs}`;
    regionaleElementText.textContent = 'Regionale prijs:';

    let btwMaandelijksElement = document.createElement('p');
    let btwMaandelijksElementText = document.createElement('p');
    btwMaandelijksElementText.style.display = 'none';
    btwMaandelijksElement.style.display = 'none';
    btwMaandelijksElement.textContent = `€${priceData.MaandelijksBtw.toFixed(2)}`;
    btwMaandelijksElementText.textContent = 'BTW:';

    let btwEenmaligElement = document.createElement('p');
    let btwEenmaligElementText = document.createElement('p');
    btwEenmaligElementText.style.display = 'none';
    btwEenmaligElement.style.display = 'none';
    btwEenmaligElement.textContent = `€${priceData.EenmaligBtw.toFixed(2)}`;
    btwEenmaligElementText.textContent = 'BTW:';

    //Add the price to the container
    maandelijkseContainer.appendChild(huurElementText);
    maandelijkseContainer.appendChild(huurElementValue);
    maandelijkseContainer.appendChild(serviceElementText);
    maandelijkseContainer.appendChild(serviceElement);
    maandelijkseContainer.appendChild(energieElementText);
    maandelijkseContainer.appendChild(energieElement);
    maandelijkseContainer.appendChild(regionaleElementText);
    maandelijkseContainer.appendChild(regionaleElement);
    maandelijkseContainer.appendChild(btwMaandelijksElementText);
    maandelijkseContainer.appendChild(btwMaandelijksElement);

    eenmaligeContainer.appendChild(waarborgElementText);
    eenmaligeContainer.appendChild(waarborgElement);
    eenmaligeContainer.appendChild(administratieElementText);
    eenmaligeContainer.appendChild(administratieElement);
    eenmaligeContainer.appendChild(btwEenmaligElementText);
    eenmaligeContainer.appendChild(btwEenmaligElement);
}

function updatePriceData(priceData) {
    ///Calculates the total price and BTW and adds it to the priceData
    let totalMonthly = 0;
    let totalOnce = 0;

    //Calculate total monthly
    totalMonthly += priceData.Huurprijs;
    totalMonthly += priceData.ServiceKosten;
    totalMonthly += priceData.EnergieKosten;
    totalMonthly += priceData.RegionalePrijs;

    //Calculate BTW based on 21% of the totalMonthly
    let btwMonthly = totalMonthly * 0.21;
    totalMonthly += btwMonthly;
    //Add BTW and total to the list
    priceData['MaandelijksBtw'] = btwMonthly;
    priceData['MaandelijksTotaal'] = totalMonthly;

    //Calculate total once
    totalOnce += priceData.Waarborg;
    totalOnce += priceData.AdministratieKosten;

    //BTW based on AdministratieKosten
    let btwOnce = priceData.AdministratieKosten * 0.21;
    totalOnce += btwOnce;
    //Add BTW and total to the list
    priceData['EenmaligBtw'] = btwOnce;
    priceData['EenmaligTotaal'] = totalOnce;

    return priceData;
}

function filterPriceData(priceData) {
    //Convert ProductId to size
    let size;
    try {
        switch (selectedSize) {
            case '12m2':
                size = 'XS';
                break;
            case '18m2':
                size = 'S';
                break;
            case '24m2':
                size = 'M';
                break;
            case '36m2':
                size = 'L';
                break;
        }
    } catch (ex) {
        showErrorMessage('Error',
            'Er is een fout opgetreden tijdens het ophalen van de prijzen. Controleer de console voor meer informatie.');
        console.log(ex.message);
    }

    //Get the price row and add regional price
    let priceRow = priceData.find((row) => row.Grootte === size);
    priceRow['RegionalePrijs'] = productData.RegionalePrijs;

    //return the price row
    return priceRow;
}

function togglePriceDetails(option) {
    // Get the container and the prijs-button
    let container = document.getElementsByClassName('prijs-lijst')[option];
    let prijsButton = container.querySelector('.prijs-button');

    // Get the current text content of the prijs-button
    let currentText = prijsButton.textContent;

    // Toggle the display of da kids
    let daKids = container.querySelectorAll(':scope > :nth-child(n+3)');
    daKids.forEach((kid) => {
        kid.style.display = (kid.style.display === 'none') ? 'block' : 'none';
    });

    // Change the text content of the prijs-button
    prijsButton.textContent = (currentText === '+') ? '-' : '+';
}

function updateDateProperties() {
    let availableDate = new Date();

    if (selectedSize != null) {
        let row = productAvailability.find((row) => row.Size === selectedSize);
        let storedDate = new Date(row.AvailableDate);

        // Check if the stored date is valid
        if (!isNaN(storedDate.getTime())) {
            availableDate = storedDate;
        }
    } else {
        dateElement.value = '';
        return;
    }

    // Add 1 day to the available date
    availableDate.setDate(availableDate.getDate() + 1);

    // Get the date in the format YYYY-MM-DD
    let minDate = availableDate.toISOString().split('T')[0];
    let maxDate = new Date(minDate);
    maxDate.setFullYear(maxDate.getFullYear() + 1);
    maxDate = maxDate.toISOString().split('T')[0];

    // Set the min attribute of the date element
    dateElement.setAttribute('min', minDate);
    dateElement.setAttribute('max', maxDate);

    //set the value of the date element to the min date
    dateElement.value = minDate;
}

function adjustProcessContainersSize() {
    let maxHeight = 0;
    let maxWidth = 0;

    //Get the max height and max width of the process containers
    for (let i = 0; i < processContainers.length; i++) {
        if (processContainers[i].offsetHeight > maxHeight) {
            maxHeight = processContainers[i].offsetHeight;
        }
        if (processContainers[i].offsetWidth > maxWidth) {
            maxWidth = processContainers[i].offsetWidth;
        }
    }

    //Set the max height and max width of the process containers
    for (let i = 0; i < processContainers.length; i++) {
        processContainers[i].style.height = maxHeight + 'px';
        processContainers[i].style.width = maxWidth + 'px';
    }
}

//Event Listeners
document.addEventListener('keydown', (event) => {
    //Closes the image and errorMessage when the escape key is pressed
    if (event.key === 'Escape') {
        hideErrorMessage();
        closeImage();
    }

    if (event.key === 'ArrowLeft') {
        changeImage('-');
    } else if (event.key === 'ArrowRight') {
        changeImage('+');
    }
})

document.addEventListener('input', () => {
    let selectedDate = new Date(dateElement.value);
    let minDate = new Date(dateElement.min);
    let maxDate = new Date(dateElement.max);

    if (selectedDate < minDate) {
        dateElement.value = minDate.toISOString().split('T')[0];
    } else if (selectedDate > maxDate) {
        dateElement.value = maxDate.toISOString().split('T')[0];
    }
})

window.addEventListener('unload', () => {
    //Clears the sessionStorage when the page is closed
    //sessionStorage.removeItem('productData');
    //sessionStorage.removeItem('productAvailability');
})

//Size element based
function getSelectedSize() {
    selectedSize = (new URL(window.location.href)).searchParams.get('selectedSize');
    return selectedSize;
}

function setSelectedSize(size) {
    //Get the size container and all the items
    const container = document.getElementsByClassName('size-container')[0];
    const items = container.querySelectorAll('.size-default');

    //Loop through all the items
    for (let i = 0; i < items.length; i++) {
        let item = items[i];

        //avoid unavailable sizes
        if (item.classList.contains('size-unavailable')) {
            continue;
        }
        //Check if the item is the selected size
        if (item.textContent === size) {
            //item.classList.remove('size-available');
            item.classList.add('size-selected');
            item.classList.remove('size-available');
        } else {
            item.classList.remove('size-selected');
            item.classList.add('size-available');
        }
    }

    //Update the availability date
    updateAvailabilityDate();
}

async function setProductOmschrijving(size) {
    let productDetails = await fetchProductDetails(size);
    document.getElementById('product-omschrijving').innerHTML = productDetails.Omschrijving;
}

function createSizeElement() {
    //#Prep
    //List for all the elements
    let elementList = [];

    //Create the size elements
    for (let i = 0; i < productAvailability.length; i++) {
        //Default attributes
        let sizeElement = document.createElement('div');
        sizeElement.textContent = productAvailability[i].Size;
        sizeElement.classList.add('size-default');
        sizeElement.onclick = async function () {
            //Set the selected size
            selectedSize = sizeElement.textContent;
            setSelectedSize(sizeElement.textContent);

            //Set the product omschrijving
            await setProductOmschrijving(sizeElement.textContent);

            //Update the availability
            updateAvailability();

            //Update the url
            window.history.pushState({}, '', `?selectedSize=${sizeElement.textContent}`);

            //Update prices
            await buildPriceElements();

            //Limit dateElement
            updateDateProperties();

            //Reset prijs-button textContent
            for (let i = 0; i < document.getElementsByClassName('prijs-button').length; i++) {
                document.getElementsByClassName('prijs-button')[i].textContent = '+';
            }
        };

        //Is it available?
        if (productAvailability[i].IsAvailable) {
            sizeElement.classList.add('size-available');
        } else {
            sizeElement.classList.add('size-unavailable');
        }

        window['sizeElement' + i] = sizeElement;
        //Add the element to the list
        elementList.push(sizeElement);
    }

    //Sorteer van klein naar groot
    elementList.sort((a, b) => {
        if (a.textContent < b.textContent) {
            return -1;
        } else if (a.textContent > b.textContent) {
            return 1;
        } else {
            return 0;
        }
    });

    return elementList;
}

function updateAvailability() {
    //Get the amount based on the selected size
    let product = productAvailability.find((item) => {
        return item.Size === selectedSize;
    });

    if (product === undefined) {
        document.getElementsByClassName('product-availability')[0].innerHTML = 'Selecteer een formaat';
        return;
    }

    //Update the availability
    if (product.Amount > 0) {
        document.getElementsByClassName('product-availability')[0].innerHTML =
            `${product.Amount} gereed voor verhuur!`;
    } else {
        document.getElementsByClassName('product-availability')[0].innerHTML =
            `Volbezet!`;
    }
}

function updateAvailabilityDate() {
    //Get the availability of the selected size
    let product = productAvailability.find((item) => {
        return item.Size === selectedSize;
    });

    //Return if the product is undefined
    if (product === undefined) {
        document.getElementsByClassName('availability-date')[0].innerHTML = '';
        return;
    }

    //Update the availability date
    let date = new Date(product.AvailableDate);
    document.getElementsByClassName('availability-date')[0].innerHTML
        = 'Beschikbaar vanaf: ' + date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
}

function addToCart() {
    //Get chosen product data
    let myProd = productAvailability.find((item) => {
        return item.Size === selectedSize;
    });

    let product = {
        'productId': myProd.ProductId,
        'locatieId': productData.LocatieId,
        'gemeente': productData.Gemeente,
        'postcode': productData.Postcode,
        'size': selectedSize,
        'available': myProd.Amount,
        'availableDate': myProd.AvailableDate,
        'startDatum': document.getElementById('datumElement').value,
        'aantalMaanden': 1,
        'imageName': listImages[0],
        'amount': 1,
        'monthly': priceData.MaandelijksTotaal,
        'once': priceData.EenmaligTotaal,
    };

    //Get cart from local storage [does not exist yet? create empty array]
    let cart = JSON.parse(localStorage.getItem('cart')) ? JSON.parse(localStorage.getItem('cart')) : [];

    //Check if the product is already in the cart
    let duplicateProducts = cart.filter((item) => {
        return item.productId === product.productId && item.locatieId === product.locatieId;
    });

    if (duplicateProducts.length > 0) {
        //Count the amount of all duplicate products
        let totalInCart = 0;
        duplicateProducts.forEach((item) => {
            totalInCart += item.amount;
        });

        //Check if we can increase the amount
        if (totalInCart + 1 > product.available) {
            showErrorMessage('Leeg gepluimd 😵‍💫', 'U heeft alle voorraad al in uw winkelmandje. Voor aanpassingen, ga naar uw winkelmandje en klik op --> Splits.');
            return;
        } else {
            //Get the index of the product
            let productIndex = cart.findIndex((item) => {
                return item.productId === product.productId && item.locatieId === product.locatieId;
            });

            //Increase the amount & save the cart
            cart[productIndex].amount++;
            localStorage.setItem('cart', JSON.stringify(cart));

            //Update the winkelmandje counter
            updateWinkelmandjeCounter();

            //Redirect to cart page
            window.location.href = '../Depo/winkelwagen.html';
            return; //Stop the function
        }
    }


    //---------------------------------------------
    //Push the product to the cart
    cart.push(product);

    //Save the cart to local storage
    localStorage.setItem('cart', JSON.stringify(cart));

    //Update the winkelmandje counter
    updateWinkelmandjeCounter();

    //Redirect to cart page
    window.location.href = '../Depo/winkelwagen.html';
}


//Next and previous image buttons
function changeImage(direction) {
    //Increase or decrease the current image index
    if (direction === '+') {
        currentImageIndex++;
    } else {
        currentImageIndex--;
    }

    //Check if the index is out of bounds
    if (currentImageIndex >= listImages.length) {
        currentImageIndex = 0;
    } else if (currentImageIndex < 0) {
        currentImageIndex = listImages.length - 1;
    }

    //Update the images
    document.getElementById('current-img').src = `/frontend-pxlprofrontendteam05/Depo/product-img/${listImages[currentImageIndex]}.jpg`;
    document.getElementById('current-img-big').src = `/frontend-pxlprofrontendteam05/Depo/product-img/${listImages[currentImageIndex]}.jpg`;
}

//Expand Image
function expandImage() {
    document.getElementById('image-gallery-big').style.display = 'flex';
}

function closeImage() {
    document.getElementById('image-gallery-big').style.display = 'none';
}

// Next and previous process buttons
function changeProcess(direction) {
    //Increase or decrease the current process index
    switch (direction) {
        case '+': {
            processStep++;
            break;
        }
        case '-': {
            processStep--;
            break;
        }
        case 0: {
            processStep = 0;
            break;
        }
        case 1: {
            processStep = 1;
            break;
        }
        case 2: {
            processStep = 2;
            break;
        }
    }

    //Check if the index is out of bounds
    if (processStep > processContainers.length - 1) {
        processStep = 0;
    } else if (processStep < 0) {
        processStep = processContainers.length - 1;
    }

    //Update the process
    for (let i = 0; i < processContainers.length; i++) {
        processContainers[i].style.display = 'none';
    }
    processContainers[processStep].style.display = 'flex';


    //Change selected nav dot
    for (let i = 0; i < navDots.length; i++) {
        navDots[i].classList.remove('nav-dot-selected');
    }
    navDots[processStep].classList.add('nav-dot-selected');
}
