
var winkelmandje = JSON.parse(localStorage.getItem("cart"));
var dataContainer = document.getElementById("dataContainer");

// Sla gegevens op in sessieopslag
sessionStorage.setItem("cart", JSON.stringify(winkelmandje));
var isProductToont = false;

document.addEventListener("DOMContentLoaded", function() {
    var winkelmandje = JSON.parse(localStorage.getItem("cart"));
    var btnSendEmail = document.getElementById("btnSendEmail");


    btnSendEmail.addEventListener("click", function () {

        if (winkelmandje && winkelmandje.length > 0 && !isProductToont) {
            var table = document.createElement("table");
            table.className = "data-table";

            var tableHeader = document.createElement("tr");

            var gemeenteHeader = document.createElement("th");
            gemeenteHeader.innerHTML = "Gemeente";
            tableHeader.appendChild(gemeenteHeader);

            var sizeHeader = document.createElement("th");
            sizeHeader.innerHTML = "Size";
            tableHeader.appendChild(sizeHeader);

            var startDatumHeader = document.createElement("th");
            startDatumHeader.innerHTML = "Start Datum";
            tableHeader.appendChild(startDatumHeader);

            table.appendChild(tableHeader);

            for (var i = 0; i < winkelmandje.length; i++) {
                var rowData = winkelmandje[i];
                var tableRow = document.createElement("tr");

                var gemeenteCell = document.createElement("td");
                gemeenteCell.innerHTML = rowData.gemeente;
                tableRow.appendChild(gemeenteCell);

                var sizeCell = document.createElement("td");
                sizeCell.innerHTML = rowData.size;
                tableRow.appendChild(sizeCell);

                var startDatumCell = document.createElement("td");
                startDatumCell.innerHTML = rowData.startDatum;
                tableRow.appendChild(startDatumCell);

                table.appendChild(tableRow);
            }

            dataContainer.appendChild(table);

            sendEmailOnCartItemAdded();
            isProductToont= true;
        } else {
            var emptyMessage = document.createElement("p");
            emptyMessage.className = "empty-message";
            //emptyMessage.innerHTML = "U heeft geen contracten";
            dataContainer.appendChild(emptyMessage);
        }

    });
    /*
    document.addEventListener("DOMContentLoaded", function () {
        var winkelmandje = JSON.parse(localStorage.getItem("cart"));
        var btnSendEmail = document.getElementById("btnSendEmail");

        btnSendEmail.addEventListener("click", function () {
            if (winkelmandje && GebruikerIngelogd()) {
                var contract = document.getElementById("contract");

                winkelmandje.forEach(function (product) {
                    var productInfoDiv = document.createElement("div");
                    productInfoDiv.innerHTML = "Gemeente: " + product.gemeente + "<br>" +
                        "Size: " + product.size + "<br>" +
                        "Start Datum: " + product.startDatum + "<br>";

                    contract.appendChild(productInfoDiv);
                });

                sendEmailOnCartItemAdded(winkelmandje);
            }
        });
    });
*/
    function sendEmailOnCartItemAdded() {
        const cartItems = JSON.parse(localStorage.getItem('cart'));
        const id = sessionStorage.getItem('userId');

        const apiUrl = 'https://localhost:7016/api/UserData/SendContract';

        const requestData = {
            "id":id,
            cartItems: cartItems.map(item => ({
                Gemeente: item.gemeente,
                Size: item.size

            }))

        };

        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        })
            .then(response => {
                if (response.ok) {
                    console.log('Artikelen succesvol verzonden.');
                } else {
                    console.error('Er is een fout opgetreden bij het verzenden van de producten.');
                }
            })
            .catch(error => {
                console.error('Er is een fout opgetreden bij het maken van het verzoek:', error);
            });
    }

    function GebruikerIngelogd() {
        // U kunt een handige methode gebruiken om de aanmeldingsstatus van gebruikers te controleren
        // U kunt bijvoorbeeld een variabele markeren als waar wanneer een gebruiker is ingelogd
        // en hier kun je de status van deze variabele controleren.
        //  In dit voorbeeld retourneert de functie userLogged In altijd true.
        return true;
    }

    function ToonProfiel() {
        let naam = document.getElementById("achternaam");
        let voornaam = document.getElementById("name");
        let email = document.getElementById("mailen");
        let naam2 = document.getElementById("naam");
        let voornaam2 = document.getElementById("voornaam");
        let emails = document.getElementById("emails");
        //let cont = document.getElementById("cont");

        let btnProfiel = document.getElementById("logIn");

        const gebruikerNaam = sessionStorage.getItem("userName");
        const gebruikerAchternaam = sessionStorage.getItem("userSurname");
        const gebruikerEmail = sessionStorage.getItem("userEmail");


        if (!gebruikerNaam == "") {
            //message.style.display = "block";
            naam.innerHTML = gebruikerAchternaam;
            voornaam.innerHTML = gebruikerNaam;
            email.innerHTML = gebruikerEmail;
            naam2.value = gebruikerAchternaam;
            voornaam2.value = gebruikerNaam;
            emails.value = gebruikerEmail;
            //cont.value = " ";


            btnProfiel.addEventListener("click", naarProfiel);
        } else {
            naam.innerHTML = " ";
            voornaam.innerHTML = " ";
            email.innerHTML = " ";
        }


    }


    window.onload = function () {
        ToonProfiel();
    };
})



