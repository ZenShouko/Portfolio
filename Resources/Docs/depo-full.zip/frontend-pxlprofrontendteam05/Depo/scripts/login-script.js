
document.addEventListener("DOMContentLoaded", function() {
    var emailInput = document.getElementById("email");
    var pass1Input = document.getElementById("pass1");
    var pass2Input = document.getElementById("pass2");

    document.getElementById("btnregistratie").addEventListener("click", function() {
        var email = emailInput.value;
        var pass1 = pass1Input.value;
        var pass2 = pass2Input.value;

        if (pass1 === pass2) {
            localStorage.setItem("email", email);
            localStorage.setItem("password", pass1);
            location.href = "registratie.html";
        }else{
            alert("Wachtwoorden komen niet overeen!");
            pass1Input.value = "";
            pass2Input.value = "";
            pass1Input.focus();
            location.href = "log-in.html";
        }




    });
});




function switchContainer(signUp){
    //Convert to vars
    let logIn = document.getElementsByClassName('login-content')[0];
    let signIn = document.getElementsByClassName('signup-content')[0];

    if (signUp === true){
        //Login Container
        logIn.style.animation = 'none';
        logIn.style.display = 'none';

        //Singin Container
        signIn.style.display = 'flex';
        signIn.style.animation = 'fadeIn 500ms ease-in';
    }
    else {
        //signIn container
        signIn.style.display = 'none';
        signIn.style.animation = 'none';

        //logIn container
        logIn.style.display = 'flex';
        logIn.style.animation = 'fadeIn 500ms ease-in';
    }
}