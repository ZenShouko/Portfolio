const sql = require('mssql');
const config = {
    user: 'PxlUserT05',
    password: 'PxlUserT05',
    server: '10.128.4.7',
    database: 'Db2023Team05',
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
};

sql.connect(config, function(err){
  if (err) {
      console.log("Connection Failed. " + err);
  }
  else{
      console.log("Connection Succes!");

      const request = new sql.Request();
      request.query('SELECT * FROM Gebruikers;', function (err, result){
          if (err) {
              console.log("Query fout: " + err);
          } else {
              console.log(result);
          }
          sql.close();
      })
  }
})

//To run this, type the following in your terminal:
//[node frontend-pxlprofrontendteam05/Depo/scripts/users-script.js]
//Dit verbind meteen naar de database via node. Dit werkt niet online alleen in Node.
//Ik neem aan dat we een web.api moeten gebruiken om onze database bloot te stellen aan http requests die we gaan uitvoeren via onze website.