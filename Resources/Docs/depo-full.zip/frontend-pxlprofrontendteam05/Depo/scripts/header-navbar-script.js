// Gebruikersnaam schrijft op de pagina
const btnProfiel = document.getElementById("logIn")
const defaultName = 'Guest'
const gebruikerNaam = sessionStorage.getItem("userName");
const message = document.getElementById("gebruiker-name");
//message.innerHTML = `Welkome ${gebruikerNaam}!`;
//Logout button

btnLogOut = document.getElementById("logout-button")
function logout() {

    // Gebruiker gegevens weg
    sessionStorage.removeItem("userName");
    sessionStorage.removeItem("userSurname");
    sessionStorage.removeItem("userEmail");
    sessionStorage.removeItem("userId");
    sessionStorage.removeItem("cardGegevens");
    localStorage.removeItem("cart");



    message.innerHTML = defaultName;
    btnLogOut.style.display = "none";
    // pagina opnieuw wordt geleid naar homepagina
    window.location.href = "index.html";
}

if (!gebruikerNaam == "") {
    //message.style.display = "block";
    message.innerHTML = gebruikerNaam;
    btnProfiel.addEventListener("click",naarProfiel);
    btnLogOut.style.display = "block";
    if (btnLogOut) {
        btnLogOut.addEventListener('click', () => {
            logout(); //De gegevens op de profielpagina gaan verloren.

        });
    }

} else {
    message.innerHTML = defaultName;
    btnLogOut.style.display = "none";
}
function naarProfiel() {
    window.location.href = "profiel.html";
}

let hamburgerOpen = false;
function hamburgerMenu(){
    let navbar = document.getElementById('navbar');
    let headerBottom = window.getComputedStyle(navbar).bottom;
    let buttonContainer = document.getElementsByClassName('button-container')[0];
    let hamburger = document.getElementById('hamburger-button');
    let winkelmandjeCounter = document.getElementById('winkelmandje-count');

    if (headerBottom !== '0px'){    //Open
        //Navbar
        navbar.style.bottom = '0px';
        navbar.style.flexDirection = 'column';
        navbar.style.background = 'rgba(0, 0, 0, 0.98)';

        //buttonContainer
        buttonContainer.style.display = 'grid';

        //Hamburger
        hamburger.style.rotate = '90deg';
        hamburgerOpen = true;

        //Winkelmandje-counter
        winkelmandjeCounter.style.bottom = '-50%';
        winkelmandjeCounter.style.right = '50%';
        winkelmandjeCounter.style.transform = 'translate(50%, -300%)';
    }
    else{ //Revert back
        //navbar
        navbar.style.bottom = 'auto';
        navbar.style.flexDirection = 'row';
        navbar.style.background = 'rgba(0, 0, 0, 0.8)';

        //buttonContainer
        buttonContainer.style.display = 'none';

        //Hamburger
        hamburger.style.rotate = 'none';
        hamburgerOpen = false;

        //Winkelmandje-counter
        winkelmandjeCounter.style.bottom = '-4px';
        winkelmandjeCounter.style.right = '4px';
        winkelmandjeCounter.style.transform = 'none';
    }
}

//Media query wordt niet altijd getriggerd dus blijft de buttonContainer op [display=none]
window.addEventListener('resize', function (){
    if (window.innerWidth > 900 && hamburgerOpen === false){
        //Show button container
        document.getElementsByClassName('button-container')[0].style.display = 'flex';
    }else if (window.innerWidth <= 900 && hamburgerOpen === false){
        document.getElementsByClassName('button-container')[0].style.display = 'none';
    }
})

// #Winkelmandje counter
function updateWinkelmandjeCounter(){
    let counterElement = document.getElementById('winkelmandje-count');
    if (!localStorage.getItem('cart')){
        counterElement.textContent = '0';
        return;
    }


    let cart = JSON.parse(localStorage.getItem('cart'));
    counterElement.textContent = cart.length;
}

window.addEventListener('DOMContentLoaded', function (){
    updateWinkelmandjeCounter();
});