
const submitBtn = document.getElementById("maakAcc");
submitBtn.addEventListener("click", function() {
    addUser();
    clearLocalStorage();
});
    // prevent the form from submitting

document.addEventListener("DOMContentLoaded", function() {
    var emailInput = document.getElementById("email");
    var passwordInput = document.getElementById("pass1");

    var storedEmail = localStorage.getItem("email");
    var storedPassword = localStorage.getItem("password");

    if (storedEmail && storedPassword) {
        emailInput.value = storedEmail;
        passwordInput.value = storedPassword;
    }
});


function addUser() {
    const apiUrl = 'https://localhost:7016/api/UserData/AddGebruiker';


    // Get form values
    var machtiging ="";
    var aanmaakDatum ="";
    var email = document.getElementById("email").value;
    var wachtwoord = document.getElementById("pass1").value;
    var achternaam = document.getElementById("naam").value;
    var voornaam = document.getElementById("voornaam").value;
    var telefoonNummer = document.getElementById("tel").value;
    var postcode = document.getElementById("post").value;
    var gemeente = document.getElementById("gemeente").value;
    var adresRegel1 = document.getElementById("adres1").value;
    var adresRegel2 = document.getElementById("adres2").value;


    // Create object with form values
    var userData = {
        "Email": email,
        "Machtiging": machtiging,
        "AanmaakDatum": aanmaakDatum,
        "VoorNaam": voornaam,
        "AchterNaam": achternaam,
        "Wachtwoord": wachtwoord,
        "TelefoonNummer": telefoonNummer,
        "Postcode": postcode,
        "Gemeente": gemeente,
        "AdresRegel1": adresRegel1,
        "AdresRegel2": adresRegel2,
    };

    fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData)
    })
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error('Failed to add user');
            }
        })
        .then(data => {
            console.log('User added:', data);
            alert('Gebruiker succesvol toegevoegd!');
        })
        .catch(error => {
            console.error(error);
            alert('An error occurred while adding the user.');
        });
}


function clearLocalStorage() {
    localStorage.clear();
    console.log("LocalStorage is leeg.");
}





