// Variables
let cart;
let cartViewDiv;
let userAgreementDiv;
let step = 1;

//Run on page load
window.addEventListener('DOMContentLoaded', () => {
    //Security check
    avoidEmptyCart();

    // Assign elements
    cart = JSON.parse(localStorage.getItem('cart'));
    cartViewDiv = document.getElementsByClassName('cart-overview')[0];
    userAgreementDiv = document.getElementsByClassName('user-agreement')[0];

    // Fill cartView with items
    fillCartView();

    //Customer name
    let customerP = document.getElementById('customer-name');
    customerP.textContent = `${sessionStorage.getItem('userName')} ${sessionStorage.getItem('userSurname')}`;

    //Adjust divs
    adjustDaDivs();
});

// Functions
async function Confirm() {
    // Block user from clicking again
    let buttons = document.getElementsByClassName('default-button');
    for (let i = 0; i < buttons.length; i++) {
        buttons[i].disabled = true;
    }

    // Get userID
    let gebruikerId = sessionStorage.getItem('userId');

    // Add userID to all cart items
    for (let i = 0; i < cart.length; i++) {
        cart[i].GebruikerId = gebruikerId;
    }

    // Save updated cart
    localStorage.setItem('cart', JSON.stringify(cart));

    let response = await confirmOrder();
    if (response.status !== 200) {
        // Show error message
        showErrorMessage('Oops!',
            'Er is een fout opgetreden tijdens het plaatsen van de bestelling.');
        return;
    }

    // Clear cart
    localStorage.removeItem('cart');

    // Success message!
    let sections = document.querySelectorAll('section');
    sections[0].style.display = 'none';
    sections[1].style.display = 'block';

    // Redirect to homepage after 5 seconds
    setTimeout(() => {
        window.location.href = '../Depo/index.html';
    }, 5000);
}

function avoidEmptyCart() {
    //Is user signed in?
    if (!sessionStorage.getItem('userName')) {
        // Go to sign in page
        window.location.href = '../Depo/log-in.html';
    }

    // Return to previous page if cart is empty
    if (!localStorage.getItem('cart')) {
        history.back();
    }
}

function fillCartView() {
    // Get sum of price and amount
    let amount = 0;
    let price = 0;
    for (let i = 0; i < cart.length; i++) {
        amount += cart[i].amount;
        price += cart[i].amount * cart[i].monthly + cart[i].once;
    }

    // Create elements
    let div = document.createElement('div');
    let amountP = document.createElement('p');
    amountP.textContent = `Products: ${amount}x`;
    div.appendChild(amountP);

    let div2 = document.createElement('div');
    let priceP = document.createElement('p');
    priceP.textContent = `Price: ${price.toFixed(2)} EUR`;
    div2.appendChild(priceP);

    // Add elements to cartView
    cartViewDiv.appendChild(div);
    cartViewDiv.appendChild(div2);
}

function adjustDaDivs() {
    // Get the three div elements
    const cartOverview = document.querySelector('.cart-overview');
    const userDiv = document.querySelector('.user-div');
    const paymentContainer = document.querySelector('.payment-container');

    if (window.innerWidth > 600){
        // Calculate the maximum width among the three divs
        const maxWidth = Math.max(
            cartOverview.offsetWidth,
            userDiv.offsetWidth,
            paymentContainer.offsetWidth
        );

        // Set the width of each div to the maximum width
        cartOverview.style.width = `${maxWidth}px`;
        userDiv.style.width = `${maxWidth}px`;
        paymentContainer.style.width = `${maxWidth}px`;
    } else{
        // Set the width of each div to auto
        cartOverview.style.width = 'auto';
        userDiv.style.width = 'auto';
        paymentContainer.style.width = 'auto';
    }

}