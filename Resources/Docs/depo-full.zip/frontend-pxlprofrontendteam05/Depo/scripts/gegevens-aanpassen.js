



const updateButton = document.getElementById("btnbewaren");

updateButton.addEventListener("click", function() {
    const apiUrl = 'https://localhost:7016/api/UserData/UpdateGebruiker';
    const id = sessionStorage.getItem('userId');
    let achternaam = document.getElementById("naam").value;
    let voornaam = document.getElementById("voornaam").value;
    let email = document.getElementById("emails").value;
    let wachtwoord1 = document.getElementById("wacht1").value;
    let wachtwoord2 = document.getElementById("wacht2").value;
    let wachtwoord;

    if (wachtwoord1 === wachtwoord2) {
        wachtwoord = wachtwoord1;
    } else {
        alert("Wachtwoorden komen niet overeen!");
        wachtwoord1.value = "";
        wachtwoord2.value = "";
        wachtwoord1.focus();
        return;
    }

    var userData = {
        "id":id,
        "achternaam": achternaam,
        "voornaam": voornaam,
        "email": email,
        "wachtwoord": wachtwoord
    };

    var options = {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(userData)
    };

    fetch(`${apiUrl}?id=${id}`, options)
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error('Failed to update user');
            }
        })
        .then(data => {
            console.log('User updated:', data);
            alert('Gebruikersinformatie is succesvol bijgewerkt!');
            window.location.href = "index.html";
        })
        .catch(error => {
            console.error(error);
            alert('Er is een fout opgetreden tijdens het bijwerken van gebruikersgegevens.');
        });
});

