


async function ingelogdBlijven() {
    try {
        await login();
    } catch (error) {
        console.error(error);
        alert('Error');
    }
}
async function login() {
    const btnInloggen = document.getElementById('login-button');
    const apiUrl = `https://localhost:7016/api/UserData/UserLogin`;

    btnInloggen.addEventListener('click', (event) => {
        event.preventDefault();

        const email = document.getElementById('logEmail').value;
        const password = document.getElementById('logPass').value;

        const user_Data = {
            Email: email,
            Wachtwoord: password
        };

        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(user_Data)
        })
            .then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error('Email of wachtwoord is incorrect');
                }
            })
            .then(data => {
                const userId = data.gebruikerId;
                const userName = data.voorNaam;
                const userSurname = data.achterNaam;
                const userEmail = data.email;

                sessionStorage.setItem('userId', userId);
                sessionStorage.setItem('userName', userName);
                sessionStorage.setItem('userSurname', userSurname);
                sessionStorage.setItem('userEmail', userEmail);


                    //Check url params for redirect
                    const urlParams = new URLSearchParams(window.location.search);
                    const redirectUrl = urlParams.get('redirect');
                    if (redirectUrl === 'winkelwagen'){
                        window.location.href = "winkelwagen.html?scrollToBottom=true";
                    } else {
                        window.location.href = "index.html";
                    }
                })

            .catch(error => {
                console.error(error);
                alert('An error occurred while logging in.');
            });

    });
}






