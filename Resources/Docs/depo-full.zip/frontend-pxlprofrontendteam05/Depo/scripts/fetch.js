const apiUrl = 'https://localhost:7016/api/UserData'

window.onload = function () {
    //fetchJSON();
    postRequest();
}

function fetchJSON() {
    fetch(apiUrl)
        .then(validateResponse)
        .then(readResponseAsJSON)
        .then(logResult)
        .catch(logError);
}



function postRequest() {
    const messageHeaders = new Headers({
        'Content-Type': 'application/json'
    })
    var string = {email:"emre.ilbay@student.pxl.be", password:"pxlvip"}
    fetch(apiUrl, {
        method: 'POST',
        body: JSON.stringify(string),
        headers: messageHeaders
    })
        .then(validateResponse)
        .then(readResponseAsJSON)
        .then(logResult)
        .catch(logError);

function validateResponse(response) {
    console.log(response)
    if (!response.ok) {
        throw Error(response.statusText);
    }
    return response;
}


function readResponseAsJSON(response) {
    return response.json(); // (1)
}

function logResult(result) {
    console.log(result);
}

function logError(error) {
    console.log('Oei, het lijkt dat er een probleem is:', error);
}



}
