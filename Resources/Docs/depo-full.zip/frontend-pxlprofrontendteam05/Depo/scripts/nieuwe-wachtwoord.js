
//De gebruiker wordt via e-mail naar deze pagina geleid voor het wijzigen van het wachtwoord.
//Moet het C# Web API-eindpunt configureren om dit FetchApi-verzoek (POST-nieuwe wachtwoord) te verwerken
const form = document.querySelector('form');
const registreren = document.querySelector('button');

registreren.addEventListener('click', (event) => {
    event.preventDefault(); // Om te voorkomen dat pagina's worden vernieuwd

    const nieuwePassword = document.getElementById('password').value;
    const confirmPassword = document.getElementById('herhaalPassword').value;
    const emailAdres = document.getElementById('email').value; // E-mail van de gebruiker

    if (nieuwePassword !== confirmPassword) {
        alert('Wachtwoorden komen niet overeen!');
    } else {
        const apiUrl = `https://localhost:7016/api/UserData`; // API-eindpunt wordt bepaald op basis van de E-mail van de gebruiker
        const data = { password: nieuwePassword,
                        emailAdres:emailAdres};
        const elementen = {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json'
            }
        };

        fetch(apiUrl, elementen)
            .then(response => response.json())
            .then(result => {
                console.log(result);
                alert('Wachtwoord succesvol veranderd!');
            })
            .catch(error => {
                console.error(error);
                alert('Er is een fout opgetreden tijdens het wijzigen van het wachtwoord!');
            });
    }
});







