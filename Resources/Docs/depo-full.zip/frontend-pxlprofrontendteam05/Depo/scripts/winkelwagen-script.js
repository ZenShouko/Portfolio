// How does it work?
// 1. On page load, the cart is updated with the new cart item from sessionStorage
// 2. The page is build with the cart items from local storage
// 3. The page is updated when the quantity/start date is adjusted
// 4. The page is updated when a cart item gets removed
// 5. The page updates when the cart empties

//prep
let cart = [];
let productenWrap;

//On page load
window.addEventListener("DOMContentLoaded", () => {
    //Update local cart variable
    updateCart();

    if (cart.length === 0) {
        buildProceedSection();
        return;
    }

    //Define catalog container
    productenWrap = document.getElementsByClassName("producten-wrap")[0];

    //Merge duplicates before building page
    mergeDuplicates();

    //Update winkelmandje counter
    updateWinkelmandjeCounter();

    //Build page on page load
    for (let i = 0; i < cart.length; i++) {
        buildPage(cart[i]);
    }

    //Add/remove "cart empty" placeholder
    cartPlaceholder();

    //Update Proceed section
    buildProceedSection();

    //Scroll to bottom of page?
    const urlParams = new URLSearchParams(window.location.search);
    const scroll = urlParams.get('scrollToBottom');
    if (scroll === 'true'){
        document.getElementsByClassName("cart-section")[1].scrollIntoView({behavior: "smooth", block: "end"}); //Scroll to bottom of page, wat half werkt >:(
    }
});

//Data related
function updateCart() {
    cart = JSON.parse(localStorage.getItem("cart")) ? JSON.parse(localStorage.getItem("cart")) : [];
}

//Page build
function buildPage(cartItem) {
    //#Receives a cart item and builds the product container for it
    //(main)Container for cart item => productenWrap
    let productContainer = document.createElement("div");
    productContainer.classList.add("product-container");
    productenWrap.appendChild(productContainer);

    // #Div for the image => productContainer
    let imageDiv = document.createElement("div");
    productContainer.appendChild(imageDiv);

    //Set image => imageDiv
    let image = document.createElement("img");
    image.src = 'product-img/' + cartItem.imageName + '.jpg';
    image.alt = 'Foto?';
    image.classList.add("product-image");
    imageDiv.appendChild(image);

    // #ProductInfo Container => productContainer
    let productInfoDiv = document.createElement("div");
    productInfoDiv.classList.add("product-info");
    productContainer.appendChild(productInfoDiv);

    //Adress paragraph => productInfoDiv
    let adressParagraph = document.createElement("p");
    adressParagraph.textContent = `${cartItem.gemeente}, ${cartItem.postcode}`;
    adressParagraph.classList.add("product-info-p");
    productInfoDiv.appendChild(adressParagraph);

    //Size paragraph => productInfoDiv
    let sizeParagraph = document.createElement("p");
    sizeParagraph.textContent = `Oppervlakte: ${cartItem.size}`;
    sizeParagraph.classList.add("product-info-p");
    productInfoDiv.appendChild(sizeParagraph);

    //Flex div => productInfoDiv
    let flexDiv = document.createElement("div");
    flexDiv.classList.add("flex");
    productInfoDiv.appendChild(flexDiv);

    //Monthly price paragraph => flexDiv
    let monthlyPriceParagraph = document.createElement("p");
    monthlyPriceParagraph.textContent = `Maandelijks: €${cartItem.monthly.toFixed(2)}`;
    monthlyPriceParagraph.classList.add("product-info-p");
    flexDiv.appendChild(monthlyPriceParagraph);

    //Once price paragraph => flexDiv
    let oncePriceParagraph = document.createElement("p");
    oncePriceParagraph.textContent = `Eenmalig: €${cartItem.once.toFixed(2)}`;
    oncePriceParagraph.classList.add("product-info-p");
    flexDiv.appendChild(oncePriceParagraph);

    //subtotal paragraph => productInfoDiv
    let subtotalParagraph = document.createElement("p");
    subtotalParagraph.classList.add("subtotaal-p");
    subtotalParagraph.textContent = `Subtotaal: €${((cartItem.monthly * cartItem.amount) + cartItem.once).toFixed(2)}`;
    productInfoDiv.appendChild(subtotalParagraph);


    // #ProductActions Container => productContainer
    let productActionsDiv = document.createElement("div");
    productActionsDiv.classList.add("product-actions-container");
    productContainer.appendChild(productActionsDiv);

    //Quantity container => productActionsDiv
    let quantityContainer = document.createElement("div");
    quantityContainer.classList.add("quantity-container");
    productActionsDiv.appendChild(quantityContainer);

    //lower button => quantityContainer
    let lowerButton = document.createElement("button");
    lowerButton.textContent = "-";
    lowerButton.onclick = () => {
        adjustAmount(quantityInput, -1, cartItem, subtotalParagraph);
    };
    quantityContainer.appendChild(lowerButton);

    //quantity input => quantityContainer
    let quantityInput = document.createElement("input");
    quantityInput.classList.add("quantity-input");
    quantityInput.type = "text";
    quantityInput.value = cartItem.amount;
    quantityInput.readOnly = true;
    quantityContainer.appendChild(quantityInput);

    //upper button => quantityContainer
    let upperButton = document.createElement("button");
    upperButton.textContent = "+";
    upperButton.onclick = () => {
        adjustAmount(quantityInput, 1, cartItem, subtotalParagraph);
    };
    quantityContainer.appendChild(upperButton);

    // #Actions Flex container => productActionsDiv
    let actionsFlexContainer = document.createElement("div");
    actionsFlexContainer.classList.add("actions-flex");
    productActionsDiv.appendChild(actionsFlexContainer);

    // #Date Container => actionsFlexContainer
    let dateContainer = document.createElement("div");
    actionsFlexContainer.appendChild(dateContainer);

    //Start date paragraph => dateContainer
    let startDateParagraph = document.createElement("p");
    startDateParagraph.textContent = "Startdatum:";
    dateContainer.appendChild(startDateParagraph);

    //Start date input => dateContainer
    let startDateInput = document.createElement("input");
    startDateInput.classList.add("input-date");
    startDateInput.type = "date";
    startDateInput.value = cartItem.startDatum;
    startDateInput.setAttribute('min', cartItem.availableDate.split('T')[0]);
    let maxDate = new Date(cartItem.availableDate);
    maxDate.setFullYear(maxDate.getFullYear() + 1);
    maxDate = maxDate.toISOString().split('T')[0];
    startDateInput.setAttribute('max', maxDate);
    startDateInput.onchange = () => {
        updateProductDate(startDateInput, cartItem);
    }
    dateContainer.appendChild(startDateInput);

    //#Duration Container => actionsFlexContainer
    let durationContainer = document.createElement("div");
    actionsFlexContainer.appendChild(durationContainer);

    //Duration paragraph => durationContainer
    let durationParagraph = document.createElement("p");
    durationParagraph.textContent = "Aantal Maanden:";
    durationContainer.appendChild(durationParagraph);

    //Duration input => durationContainer
    let durationInput = document.createElement("input");
    durationInput.classList.add("input-text");
    durationInput.type = "text";
    durationInput.onchange = () => {
        updateDuration(durationInput, cartItem);
    }
    durationInput.value = cartItem.aantalMaanden;
    durationContainer.appendChild(durationInput);

    // #button container => actionsFlexContainer
    let buttonContainer = document.createElement("div");
    buttonContainer.classList.add("cart-button-div");
    actionsFlexContainer.appendChild(buttonContainer);

    // #Remove button => buttonContainer
    let removeButton = document.createElement("button");
    removeButton.textContent = "Verwijderen";
    removeButton.onclick = () => {
        removeItem(cartItem)
    };
    buttonContainer.appendChild(removeButton);

    // Split button => buttonContainer
    let splitButton = document.createElement("button");
    splitButton.textContent = "Split";
    splitButton.onclick = () => {
        splitCartItem(cartItem, quantityInput, subtotalParagraph);
    }
    buttonContainer.appendChild(splitButton);

    console.log(`Added ${cartItem.productId} to cart.`);
}

function buildProceedSection() {
    let loginButton = document.getElementById('logInButton');
    let continueButton = document.getElementById('continueButton');
    let backButton = document.getElementById('backToShopButton');
    let warningParagraph = document.getElementById('warning-p');
    let totaalParagraph = document.getElementById('totaalBedrag-p');
    let totaalDiv = document.getElementById('totaal-div');

    //Is cart empty?
    if (cart.length === 0) {
        totaalDiv.style.display = "none";
        warningParagraph.style.display = "none";
        continueButton.style.display = "none";
        loginButton.style.display = "none";
        backButton.style.display = "block";
        return;
    }

    //--------------------------------------------//
    //@Cart is not empty
    backButton.style.display = "none";

    //Calculate total price
    let totalPrice = 0;
    for (let i = 0; i < cart.length; i++) {
        totalPrice += (cart[i].monthly * cart[i].amount) + cart[i].once;
    }

    // Assign total price to total price paragraph
    totaalParagraph.textContent = `Totaal: €${totalPrice.toFixed(2)}`;

    //Is user logged in?
    if (!sessionStorage.getItem('userId')){
        warningParagraph.style.display = "block";
        warningParagraph.textContent = "U moet ingelogd zijn om verder te gaan.";
        continueButton.style.display = "none";
        loginButton.style.display = "block";
    } else {
        warningParagraph.style.display = "none";
        continueButton.style.display = "block";
        loginButton.style.display = "none";
    }
}

function cartPlaceholder() {
    if (cart.length === 0) {
        document.getElementsByClassName('cart-placeholder')[0].style.display = "block";
    } else {
        document.getElementsByClassName('cart-placeholder')[0].style.display = "none";
    }
}

function adjustAmount(element, direction, cartItem, subtotalParagraph) {
    // *Exception, if available is 0 or 1, amount can't be adjusted*
    if (cartItem.available === 0 || cartItem.available === 1) {
        return;
    }

    // #Get total of all cartItems
    let inCart = 0;

    //Loop through cart
    for (let i = 0; i < cart.length; i++) {
        if (cart[i].productId === cartItem.productId &&
            cart[i].locatieId === cartItem.locatieId) {
            inCart += cart[i].amount;
        }
    }

    //Get current item's amount
    let amount = parseInt(element.value);

    //Execute direction
    amount += direction;

    //Check if amount is within bounds
    if (amount < 1) {
        amount = 1;
    } else if (inCart + direction > cartItem.available) { //Overflow
        //amount = cartItem.available - inCart;
        return;
    }

    //Update element's value
    element.value = amount;

    //Update cartItem in local storage
    let cartIndex = cart.indexOf(cartItem); //Get index of item in cart
    cart[cartIndex].amount = amount; //Update amount of item in cart
    localStorage.setItem("cart", JSON.stringify(cart)); //Update cart in local storage

    //Update subtotal
    subtotalParagraph.textContent = `Subtotaal: €${((cartItem.monthly * amount) + cartItem.once).toFixed(2)}`;

    //Update proceed section
    buildProceedSection();
}

function removeItem(cartItem) {
    //Remove item from local storage
    let cartIndex = cart.indexOf(cartItem); //Get index of item in cart
    cart.splice(cartIndex, 1); //Remove item from cart

    //select all children of productenWrap
    let children = productenWrap.children;
    //remove the child at the index of the cartItem
    productenWrap.removeChild(children[cartIndex + 1]); //+1 because of the cart-placeholder


    localStorage.setItem("cart", JSON.stringify(cart)); //Update cart in local storage

    cartPlaceholder(); //Display placeholder if cart is empty
    buildProceedSection(); //Update proceed section
    updateWinkelmandjeCounter(); //Update winkelmandje counter
}

function splitCartItem(cartItem, inputElement, subtotalParagraph) {
    //Get index of item in cart
    let cartIndex = cart.indexOf(cartItem);

    //Check if Amount exceeds available
    //Only allow 2 duplicate items
    let duplicateItems = cart.filter(item => item.productId === cartItem.productId && item.locatieId === cartItem.locatieId);

    if (duplicateItems.length >= 2) {
        showErrorMessage("Hallo, dev-team hier!", "We hebben de split functie gelimiteerd naar 1 maal. " +
            "Dit om kopzorgen te verminderen. Liefst en kusjes, het dev-team xoxo");
        return;
    }

    let totalInCart = 0;
    duplicateItems.forEach(item => totalInCart += item.amount);

    //If amount + 1 exceeds available, decrease amount for split
    if (totalInCart + 1 > cartItem.available && cartItem.amount > 1) {
        adjustAmount(inputElement, -1, cartItem, subtotalParagraph);
    } else if (totalInCart + 1 > cartItem.available) {
        //If amount + 1 exceeds available and amount !> 1, return
        return;
    }

    //Create new cartItem
    let newCartItem = { ...duplicateItems[0] };
    newCartItem.amount = 1;

    //Add new cartItem to cart
    cart.splice(cartIndex + 1, 0, newCartItem);

    //Update cart in local storage
    localStorage.setItem("cart", JSON.stringify(cart));

    //Update cart in DOM
    buildPage(newCartItem);

    //Update proceed section
    buildProceedSection();

    //Update winkelmandje counter
    updateWinkelmandjeCounter();
}

function updateProductDate(element, cartItem) {
    if (element.value < element.min) {
        element.value = element.min;
    } else if (element.value > element.max) {
        element.value = element.max;
    }

    let cartIndex = cart.findIndex(item => item === cartItem); //Get index of item in cart
    cart[cartIndex].startDatum = element.value; //Update startDatum in cart
    localStorage.setItem("cart", JSON.stringify(cart)); //Update cart in local storage
}

function updateDuration(element, cartItem) {
    if (isNaN(parseInt(element.value))) {
        element.value = cartItem.aantalMaanden;
    } else {
        //Update aantal maanden in cart for cartItem
        let cartIndex = cart.findIndex(item => item === cartItem); //Get index of item in cart
        cart[cartIndex].aantalMaanden = parseInt(element.value.trim()); //Update aantalMaanden in cart
        localStorage.setItem("cart", JSON.stringify(cart)); //Update cart in local storage
        element.value = cart[cartIndex].aantalMaanden; //Just to be sure
    }
}


function mergeDuplicates() {
    // Big shootout to my homie who wrote this code, @Chat_GPT, peace out bro.
    //Check for duplicates inside cart
    //If duplicates exist, merge them
    //If duplicates don't exist, proceed to checkout
    //An item is a duplicate if it has the same productId, locatieId, startDatum and aantalMaanden
    let duplicates = {};

    // Iterate through the cart array
    for (let i = 0; i < cart.length; i++) {
        let currentItem = cart[i];

        // Generate a unique key for the current item based on the specified attributes
        let key = `${currentItem.productId}_${currentItem.locatieId}_${currentItem.startDatum}_${currentItem.aantalMaanden}`;

        // Check if a duplicate with the same key exists
        if (duplicates.hasOwnProperty(key)) {
            // If a duplicate is found, increment the amount of the existing duplicate
            duplicates[key].amount += currentItem.amount;
        } else {
            // If no duplicate is found, add the current item to the duplicates object
            duplicates[key] = { ...currentItem };
        }
    }

    // Convert the duplicates object back to an array
    let mergedCart = Object.values(duplicates);

    // Update the cart array and the corresponding cart item in local storage
    cart = mergedCart;
    localStorage.setItem('cart', JSON.stringify(mergedCart));
}


function proceedPurchase(){
    mergeDuplicates();

    //Proceed to checkout
    window.location.href = "checkout.html";
}