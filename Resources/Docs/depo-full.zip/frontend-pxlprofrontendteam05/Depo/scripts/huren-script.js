let locationList; //Local List of all locations
let smallestSize; //Smallest size of the selected location

//Run after page load
window.addEventListener('DOMContentLoaded', () => {
    //Set selected option from url
    setSelectedOptionFromUrl(getSelectedOptionFromUrl());
    //Get all locations on page load
    getLocations();
});

//Read Url parameters
function getSelectedOptionFromUrl() {
    return (new URL(window.location.href)).searchParams.get('selectedOption');
}

function setSelectedOptionFromUrl(option) {
    if (option === 'Container' || option === 'Tuinen') {
        setTimeout(() => {
            showErrorMessage('Coming Soon!', 'Deze functie is nog niet beschikbaar.');

            //Verwijder parameter uit url
            window.history.pushState({}, null, 'http://localhost:63342/frontend-pxlprofrontendteam05/Depo/huren.html');
        }, 1000);
    }

    //Eenmaal Containers beschikbaar zijn, kan deze functie gebruikt worden
    //document.getElementById('select-type').value = option;

    //If option is null, set default value
    if (option === null) {
        document.getElementById('select-type').value = 'Garage';
    }
}

//Redirect user
function openProductDetails(productData) {
    sessionStorage.setItem('productData', JSON.stringify(productData));
    sessionStorage.removeItem('productAvailability');
    window.location.href = 'product.html';
}

function openProductDetailsWithSize(productData, selectedSize, productAvailability) {
    sessionStorage.setItem('productData', JSON.stringify(productData));
    sessionStorage.setItem('productAvailability', JSON.stringify(productAvailability));
    window.location.href = `product.html?selectedSize=${selectedSize}`;
}

//Get functions [Select, onchange]
function getLocations() {
    //Get location based on type
    let boxType = document.getElementById('select-type').value;

    if (boxType.toUpperCase() === 'GARAGE') {
        fetchLocations();
    } else if (boxType.toUpperCase() === 'CONTAINER') {
        console.log('Lol, we hebben geen containers. (Prank)');
        document.getElementById('select-locations').innerHTML = '';
        document.getElementById('select-sizes').innerHTML = '';
    }
}

function getSizes() {
    //Get sizes based on location
    let gemeente = document.getElementById('select-locations').value;

    fetchSizes(gemeente);
}

//Add functions
function addLocationToSelectbox(location) {
    const optionElement = document.createElement("option");
    const optionExists = document.getElementById('select-locations').querySelector(`[value="${location['Gemeente']}"]`);

    if (!optionExists) {
        optionElement.value = location['Gemeente'];
        optionElement.textContent = `${location['Postcode']} - ${location['Gemeente']}`;
        document.getElementById('select-locations').appendChild(optionElement);
    }
}

function addSizeToSelectbox(sizes) {
    //Voeg alle beschikbare groottes toe aan de lijst
    let availableSizes = [];
    if (sizes['XS'] > 0) {
        availableSizes.push('12m²');
    }
    if (sizes['S'] > 0) {
        availableSizes.push('18m²');
    }
    if (sizes['M'] > 0) {
        availableSizes.push('24m²');
    }
    if (sizes['L'] > 0) {
        availableSizes.push('36m²');
    }

    //Add all available sizes to the selectbox
    const optionElement = document.createElement("p");
    availableSizes.forEach(size => {
        optionElement.textContent += size + ', ';
    });
    optionElement.textContent = optionElement.textContent.slice(0, -2);

    //If no sizes are available, display message
    if (availableSizes.length === 0) {
        optionElement.textContent = 'Geen beschikbare groottes.';
    }

    //Add element to container
    document.getElementById('select-sizes').appendChild(optionElement);
}


//Search Functions
function search() {
    //Clear all products
    clearCatalogus();

    //Fetch products
    fetchProducts(document.getElementById('select-type').value, document.getElementById('select-locations').value)
        .then(products => {
            products.forEach(prod => createProductContainer(prod));
        })
        .catch(error => {
            console.log(error.message);
            showErrorMessage('Fetch Error.',
                'Er is een fout opgetreden tijdens het ophalen van de producten. Controleer de console voor meer informatie.');
        });
}

//Modify elements
async function createProductContainer(productData) {
    //The parent container
    const parentContainer = document.getElementsByClassName('catalogus-section')[0];

    //The product container => parentContainer
    const productContainer = document.createElement('div');
    productContainer.classList.add('product-container');

    //The product thumbnail => productContainer
    const productThumbnail = document.createElement('img');
    productThumbnail.classList.add('product-thumbnail');
    let listImages = productData['ListImageNames'];
    let imageName = listImages[0];
    productThumbnail.src = "product-img/" + imageName + ".jpg";
    productThumbnail.alt = "Product image";
    productThumbnail.onclick = function () {
        openProductDetails(productData);
    }
    productThumbnail.style.cursor = 'pointer';
    productContainer.appendChild(productThumbnail);

    //The product info container => productContainer
    const productInfoContainer = document.createElement('div');
    productInfoContainer.classList.add('product-info-container');
    productContainer.appendChild(productInfoContainer);

    //The product title => productInfoContainer
    const productTitle = document.createElement('h1');
    productTitle.classList.add('product-title');
    productTitle.textContent = productData['Gemeente'];
    productTitle.onclick = function () {
        openProductDetails(productData);
    }
    productTitle.style.cursor = 'pointer';
    productInfoContainer.appendChild(productTitle);

    //The address price container => productInfoContainer
    const addressPriceContainer = document.createElement('div');
    addressPriceContainer.classList.add('product-adres-price-container');
    productInfoContainer.appendChild(addressPriceContainer);

    //The product address => addressPriceContainer
    const productAdress = document.createElement('p');
    productAdress.classList.add('adres-p');
    productAdress.textContent = `${productData['Adres']}, ${productData['Postcode']} ${productData['Gemeente']}`;
    addressPriceContainer.appendChild(productAdress);

    //The product price => addressPriceContainer
    const productPrice = document.createElement('p');
    productPrice.classList.add('price-p');


    //The product size container => productInfoContainer
    const productSizeContainer = document.createElement('div');
    productSizeContainer.classList.add('product-size-container');
    productInfoContainer.appendChild(productSizeContainer);

    //Size container - Header => productSizeContainer
    const productSizeHeader = document.createElement('p');
    productSizeHeader.textContent = 'Beschikbare maten:';
    productSizeContainer.appendChild(productSizeHeader);

    //Size container - Sizes => productSizeContainer
    const productSizes = document.createElement('div');
    productSizes.classList.add('product-sizes');
    productSizeContainer.appendChild(productSizes);

    //Possible sizes
    let sizes = await createSizeElements(productData);
    sizes.forEach(size => {
        productSizes.appendChild(size);
    });

    //Get the lowest price based on the smallest size
    calculatePrice(productData).then(price => {
        productPrice.textContent = `€${price},- p/m`;
    });
    addressPriceContainer.appendChild(productPrice);

    //The product container => parentContainer
    parentContainer.appendChild(productContainer);

    //TODO: Limit the amount of products shown (to 5 products maybe?)
}

function clearCatalogus() {
    const catalogus = document.getElementsByClassName('catalogus-section')[0];
    while (catalogus.firstChild) {
        catalogus.removeChild(catalogus.firstChild);
    }
}

//Calculations
async function calculatePrice(data) {
    let price = null;

    //Get the smallest size [Converts from numbers to letters]
    switch (smallestSize){
        case '12m2':{
            smallestSize = 'XS';
            break;
        }
        case '18m2':{
            smallestSize = 'S';
            break;
        }
        case '24m2':{
            smallestSize = 'M';
            break;
        }
        case '36m2':{
            smallestSize = 'L';
            break;
        }
    }

    try {
        let priceData = await fetchPrices();
        let priceRow = priceData.find(p => p['Grootte'] === smallestSize);
        if (!priceRow) {
            showErrorMessage('Fout bij het ophalen van de prijs', 'Er is een fout opgetreden bij het ophalen van de prijs. Probeer het later opnieuw?');
            console.log("Couldn't find the price row matching the smallest size.");
            return;
        }

        //Add costs to total price
        price = 0;
        price += priceRow['Huurprijs'];
        price += priceRow['ServiceKosten'];
        price += priceRow['EnergieKosten'];
        price += priceRow['Waarborg'];
        price += priceRow['AdministratieKosten'];
        //Add regional price
        price += data['RegionalePrijs'];
    } catch (error) {
        console.log(error.message);
        showErrorMessage('Fetch Error.',
            'Er is een fout opgetreden tijdens het ophalen van de producten. Controleer de console voor meer informatie.');
    }
    return price;
}

async function createSizeElements(productData) {
    //todo: use fetchSizesBasedOnLocation(locatieId); to get the possible sizes
    let productAvailability = await fetchProductAvailability(productData.LocatieId);
    smallestSize = null;
    //#Prep
    //List for all the elements
    let elementList = [];

    //Create the size elements
    for (let i = 0; i < productAvailability.length; i++) {
        //Default attributes
        let sizeElement = document.createElement('div');
        sizeElement.textContent = productAvailability[i].Size;
        sizeElement.classList.add('size-default');
        sizeElement.onclick = function () {
            //Open the product details
            openProductDetailsWithSize(productData, sizeElement.textContent, productAvailability);
        }

        //Is it available?
        if (productAvailability[i].IsAvailable) {
            sizeElement.classList.add('size-available');
        } else {
            sizeElement.classList.add('size-unavailable');
        }

        window['sizeElement' + i] = sizeElement;
        //Add the element to the list
        elementList.push(sizeElement);
    }

    //Sorteer van klein naar groot
    elementList.sort((a, b) => {
        if (a.textContent < b.textContent) {
            return -1;
        } else if (a.textContent > b.textContent) {
            return 1;
        } else {
            return 0;
        }
    });

    //[Define the smallest size]
    //First get the smallest available size
    //If there is no available size, get the smallest unavailable size
    if (elementList.some(e => e.classList.contains('size-available'))) {
        smallestSize = elementList.find(e => e.classList.contains('size-available')).textContent;
    } else {
        smallestSize = elementList[0].textContent;
    }

    return elementList;
}
