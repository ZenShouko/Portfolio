function switchProfile(profile){
    //Convert to vars
    let profileStatic = document.getElementsByClassName('profile-content')[0];
    let profileChange = document.getElementsByClassName('profile-change-content')[0];

    if (profile === true){
        //profileStatic container
        profileStatic.style.display = 'none';
        profileStatic.style.animation = 'none';

        //profileChange container
        profileChange.style.display = 'flex';
        profileChange.style.animation = 'fadeIn 500ms ease-in';
    }
    else {
        //profileChange Container
        profileChange.style.animation = 'none';
        profileChange.style.display = 'none';

        //profileStatic Container
        profileStatic.style.display = 'flex';
        profileStatic.style.animation = 'fadeIn 500ms ease-in';
    }
}
