function redirectUser() {
    // Get the value of the selected option
    let option = document.getElementById('product-option-select').value;

    // Redirect user based on selected option
    switch (option) {
        case 'Keuzehulp':
            window.location.href = 'keuzehulp.html';
            break;
        case 'Tuin':
            console.log('Lol, we hebben geen tuinen. (Prank)');
            break;
        case 'Garage':
            window.location.href = `huren.html?selectedOption=${option}`;
            break;
        case 'Container':
            window.location.href = `huren.html?selectedOption=${option}`;
            break;
    }
}