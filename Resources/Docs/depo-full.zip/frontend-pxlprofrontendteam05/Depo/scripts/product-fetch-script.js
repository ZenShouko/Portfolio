// A collection of functions to fetch data from the API.
// Also contains the functions to display loading indicator and error messages.

//Global variables
let errorMessage;
let loadingIndicator;

window.addEventListener('DOMContentLoaded', () => {
    //Get elements
    errorMessage = document.getElementsByClassName('error')[0];
    loadingIndicator = document.getElementsByClassName('loading')[0];
});

// FETCH FUNCTIONS
function fetchPrices() {
    showLoadingIndicator(); //Show loading indicator

    return fetch('https://localhost:7016/api/Product/Prijzen', {
        method: 'GET',
        headers: new Headers({
            'Content-Type': 'application/json'
        })
    })
        .then((response) => {
            return response.json();
        })
        .catch((error) => {
            console.log(error.message);
            showErrorMessage('Fetch Error.',
                'Er is een fout opgetreden tijdens het ophalen van de groottes. Controleer de console voor meer informatie.');
        })
        .finally(() => {
            //Hide loading indicator
            hideLoadingIndicator();
        });
}

function fetchProductAvailability(locatieID) {
    showLoadingIndicator(); //Show loading indicator

    return fetch('https://localhost:7016/api/Product/ProductAvailability', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify({"LocatieId": locatieID})
    })
        .then((response) => {
            return response.json();
        })
        .catch((error) => {
            console.log(error.message);
            showErrorMessage('Fetch Error.',
                'Er is een fout opgetreden tijdens het ophalen van de groottes. Controleer de console voor meer informatie.');
        })
        .finally(() => {
            //Hide loading indicator
            hideLoadingIndicator();
        });
}

function fetchLocations() {
    showLoadingIndicator(); //Show loading indicator

    //Fetch to api to get all locations
    fetch("https://localhost:7016/api/Product/Locations", {
        method: 'GET',
        headers: new Headers({
            'Content-Type': 'application/json'
        })
    })
        .then((response) => {
            if (!response.ok) {
                throw Error('Er is een fout opgetreden tijdens het fetchen.');
            } else {
                return response.json();
            }
        })
        .then((allLocations) => {
            locationList = allLocations;

            //Clear selectbox and add options
            document.getElementById('select-locations').innerHTML = '';
            locationList.forEach(location => addLocationToSelectbox(location));
            getSizes();
        })
        .catch((error) => {
            //Show error message
            console.log(error.message);
            showErrorMessage('Fetch error.',
                'Er is een fout opgetreden tijdens het ophalen van de locaties. Controleer de console voor meer informatie.')
        })
        .finally(() => {
            //Hide loading indicator
            hideLoadingIndicator();
        });
}

function fetchSizes(gemeente) {
    showLoadingIndicator(); //Show loading indicator

    //Fetch to api to get all available sizes based on location
    fetch('https://localhost:7016/api/Product/Groottes', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify({"Gemeente": gemeente})
    })
        .then((response) => {
            if (response.ok) {
                return response.json();
            }
        })
        .then((availableSizes) => {
            //Clear selectbox and add options
            document.getElementById('select-sizes').innerHTML = '';
            addSizeToSelectbox(availableSizes);
        })
        .catch((error) => {
            console.log(error.message);
            showErrorMessage('Fetch Error.',
                'Er is een fout opgetreden tijdens het ophalen van de groottes. Controleer de console voor meer informatie.');
        })
        .finally(() => {
            //Hide loading indicator
            hideLoadingIndicator();
        });
}

function fetchSizesBasedOnLocation(locatieId) {
    showLoadingIndicator(); //Show loading indicator

    return fetch('https://localhost:7016/api/Product/GroottesPerPark', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify({"LocatieId": locatieId})
    })
        .then((response) => {
            if (!response.ok) {
                throw Error('Er is een fout opgetreden tijdens het fetchen.');
            } else {
                return response.json();
            }
        })
        .catch((error) => {
            console.log(error.message);
            showErrorMessage('Fetch Error.',
                'Er is een fout opgetreden tijdens het ophalen van de groottes (based on location). Controleer de console voor meer informatie.');
        })
        .finally(() => {
            //Hide loading indicator
            hideLoadingIndicator();
        });
}

function fetchProducts(type, gemeente) {
    showLoadingIndicator(); //Show loading indicator

    return fetch('https://localhost:7016/api/Product/Products', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify({"Type": type, "Gemeente": gemeente})
    })
        .then((response) => {
            if (!response.ok) {
                throw Error('Er is een fout opgetreden tijdens het fetchen.');
            } else {
                return response.json();
            }
        })
        .then((allProducts) => {
            return allProducts;
        })
        .catch((error) => {
            console.log(error.message);
            showErrorMessage('Fetch Error.',
                'Er is een fout opgetreden tijdens het ophalen van de groottes. Controleer de console voor meer informatie.');
            return null;
        })
        .finally(() => {
            hideLoadingIndicator();
        });
}

function fetchProductDetails(size) {
    return fetch('https://localhost:7016/api/Product/ProductDetails', {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify({"Size": size})
    })
        .then((response) => {
            return response.json();
        })
        .catch((error) => {
            showErrorMessage('Fetch Error.', 'Er is een fout opgetreden tijdens het ophalen van de omschrijving. Controleer de console voor meer informatie.')
            console.log(error.message)
        })
        .finally(() => {
            //Hide loading indicator
            hideLoadingIndicator();
        });
}


// PUT REQUESTS
function confirmOrder() {
    showLoadingIndicator(); //Show loading indicator
    let cart = JSON.parse(localStorage.getItem('cart'));
    console.log(cart);

    return fetch('https://localhost:7016/api/Product/NewOrder', {
        method: 'PUT',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(cart)
    })
        .then((response) => {
            return response;
        })
        .catch((error) => {
            console.log(error.message)
        })
        .finally(() => {
            //Hide loading indicator
            hideLoadingIndicator();
        });
}

//Loading indicator & error messages
function showLoadingIndicator() {
    // Assign loading indicator to variable if not already done
    if (loadingIndicator === undefined) {
        loadingIndicator = document.getElementsByClassName('loading')[0];
    }

    //Try catch to prevent errors when loading indicator is not on page
    try {
        if (loadingIndicator.style.opacity > 0) return;

        loadingIndicator.style.top = '4em';
        loadingIndicator.style.opacity = '1';
    } catch (e) {
        console.log(e);
    }
}

function hideLoadingIndicator() {
    loadingIndicator.style.top = '-1em';
    loadingIndicator.style.opacity = '0';
}

function showErrorMessage(header, message) {
    while (errorMessage === undefined) {
        errorMessage = document.getElementsByClassName('error-message')[0];
    }
    errorMessage.style.visibility = 'visible';
    errorMessage.style.opacity = '1';

    document.getElementById('error-header').textContent = header;
    document.getElementById('error-message').textContent = message;
}

function hideErrorMessage() {
    errorMessage.style.opacity = '0';

    setTimeout(() => {
        errorMessage.style.visibility = 'hidden';
    }, 100);
}