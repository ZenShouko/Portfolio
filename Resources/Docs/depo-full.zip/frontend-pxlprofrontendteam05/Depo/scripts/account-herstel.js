

const resetPasswordButton = document.getElementById('btnReset');
resetPasswordButton.addEventListener('click', () => {
    const email = document.getElementById('email').value;

    const apiUrl = 'https://localhost:7016/api/UserData/ResetPassword';

    const requestData = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(email)
    };

    fetch(apiUrl, requestData)
        .then(response => {
            if (!response.ok) {
                throw new Error('Verzoek fout: ' + response.status);
            }
            return response.json();
        })
        .then(result => {
            if (result && result.message === "success") {
                console.log(result);
                alert('Nieuwe Wachtwoord is verzonden.');
            } else {
                throw new Error('Wachtwoord resetten mislukt.');
            }
        })
        .catch(error => {
            console.error(error);
            alert('Wachtwoord resetten mislukt.');
        });


});
