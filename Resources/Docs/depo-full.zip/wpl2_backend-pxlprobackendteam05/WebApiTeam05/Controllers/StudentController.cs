﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ClassLibTeam05.Business;
using Newtonsoft.Json;

namespace WebApiTeam05.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        [HttpGet]
        public ActionResult GetStudents()
        { 
            var students = Students.GetStudents(); 
            return Ok(students); 
        }

        //voorbeeld van Sander

        //public string Students() 
        //{
        //    //var results = Students.GetStudents();

        //    //if (results.Succeeded)
        //    //{
        //    //    var students = results.Datatable;
        //    //    string JSONresult = JsonConvert.SerializeObject(students);
        //    //    return Ok(JSONresult);
        //    //}
        //    //return NotFound();

        //    return "Emma, Emre, Tacettin, Fatma";
        //}

        //[HttpPost]
        //public string AddStudent(string naam)
        //{
        //    return $"{naam} stinkt";
        //}
    }
}
