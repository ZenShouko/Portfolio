﻿using ClassLibTeam05;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Text.Encodings.Web;
using System.Web;
using Newtonsoft.Json;
using System.Text.Json;
using System.Text.Json.Nodes;
using Newtonsoft.Json.Linq;
using System.Data.SqlClient;
using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Business;
using ClassLibTeam05.Data.Framework;
using ClassLibTeam05.Data;
using System.Net.Mail;
using System.Net;
using System.Text;

namespace WebApiTeam05.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserDataController : ControllerBase
    {


        [HttpPost("AllGebruikers")]
        public ActionResult AllGebruikers()
        {

            var result = Gebruikers.GetGebruikers();
            if (result.Succeeded)
            {
                var gebruikers = result.DataTable;
                string Jsonresult = JsonConvert.SerializeObject(gebruikers);
                return Ok(Jsonresult);
            }
            return NotFound();

        }

        [HttpPost("UserLogin")]
        public ActionResult UserLogin([FromBody] Gebruiker gebruiker) // 
        {
            try
            {

                var user = GebruikerData.GetUserByEmailAndPassword(gebruiker.Email, gebruiker.Wachtwoord);
                if (user != null)
                {
                    string userData = GebruikerData.GetUserData(user.Email);
                    string[] parts = userData.Split(';');

                    var gebruikerData = new
                    {
                        GebruikerId = parts[0],
                        VoorNaam = parts[2],
                        AchterNaam = parts[3],
                        Email = parts[1]
                    };

                    return Ok(gebruikerData);

                    //return Ok(user);
                }
                else
                {

                    return BadRequest("Email of wachtwoord is incorrect");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }




        [HttpPost("CheckEmail")]
        public ActionResult CheckEmailExistence([FromBody] object emailObj)
        {
            if (emailObj == null) { return BadRequest(); }

            Gebruiker gebruiker = JsonConvert.DeserializeObject<Gebruiker>(emailObj.ToString());

            try
            {
                Database.CheckEmailExistence(gebruiker.Email);
            }
            catch
            {
                return NotFound();
            }
            return Ok();
        }



        [HttpPost("AddGebruiker")]

        public ActionResult AddGebruiker([FromBody] Gebruiker gebruiker)
        {
            if (gebruiker == null) { return NotFound(); }
            try
            {
                // Controleer de overeenkomende waarde en stel de standaardwaarde in
                gebruiker.Machtiging = string.IsNullOrEmpty(gebruiker.Machtiging) ? "User" : gebruiker.Machtiging;

                gebruiker.AanmaakDatum = DateTime.Now.Date;

                var result = Gebruikers.AddGebruiker(gebruiker);
                if (result.Succeeded)
                {
                    var gebruikerData = result.DataTable;
                    string JSONresult = JsonConvert.SerializeObject(gebruikerData);
                    return Ok(JSONresult);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
        [HttpPut("UpdateGebruiker")]

        public ActionResult UpdateGebruiker(int id, Gebruiker updatedGebruiker)
        {
            Gebruiker existingGebruiker = GebruikerData.GetGebruikerById(id);
            if (existingGebruiker == null)
            {
                return NotFound();
            }

            existingGebruiker.AchterNaam = updatedGebruiker.AchterNaam;
            existingGebruiker.VoorNaam = updatedGebruiker.VoorNaam;
            existingGebruiker.Email = updatedGebruiker.Email;
            existingGebruiker.Wachtwoord = updatedGebruiker.Wachtwoord;


            GebruikerData.UpdateGebruikerInDatabase(existingGebruiker);


            return Ok(existingGebruiker);
        }

      

        [HttpPost("SendContract")]
        public ActionResult SendEmail(int id, Product cartItems)
        {
            Product producten = new Product();

            producten.Type= cartItems.Type;
            producten.Gemeente = cartItems.Gemeente;
            producten.ProductId = cartItems.ProductId;
            producten.Size= cartItems.Size;
            producten.Omschrijving= cartItems.Omschrijving;

            try
            {
                //Vereiste informatie voor het verzenden van e-mail
                string fromEmail = "depodenopschlagh@wplpxl.be";
                string fromPassword = "WerkpleklerenTeam05";
                string subject = "Winkelwagen Inhoud";
                string body = "Artikelen in uw winkelwagen:\n ";

                    body += $"Gemeente: {cartItems.Gemeente}\nSize: {cartItems.Size}\n\n";
               

                //Het e-mailadres van de gebruiker op uit de database
                string toEmail = GebruikerData.GetUserEmailFromDatabase(id);
        
                // SmtpClient object
                SmtpClient smtpClient = new SmtpClient("smtp.Strato.com", 587);
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new NetworkCredential(fromEmail, fromPassword);

                // MailMessage object
                MailMessage mailMessage = new MailMessage(new MailAddress(fromEmail), new MailAddress(toEmail))
                {
                    Subject = subject,
                    Body = body
                };

                
                smtpClient.Send(mailMessage);

                return Ok("E-mail succesvol verzonden.");
            }
            catch (Exception ex)
            {
                return BadRequest("Er is een fout opgetreden tijdens het verzenden van de e-mail: " + ex.Message);
            }
        }


        [HttpPost("ResetPassword")]
        public ActionResult ResetPassword([FromBody] string email)
        {
           
            var userMail = GebruikerData.GetUserByEmail(email);
            Gebruiker gebruiker = new Gebruiker();

            if (userMail == null)
            {
             
                return BadRequest("Gebruiker is niet gevonden.");
            }

            try
            {
              
                string newPassword = GebruikerData.GenerateRandomPassword();

               
                GebruikerData.UpdateUserPassword(gebruiker.GebruikerId, newPassword);
               
               
                GebruikerData.SendPasswordResetEmail(userMail, newPassword);

                return Ok("Nieuwe wachtwoord is verzonden");
            }
            catch (Exception ex)
            {
                return BadRequest("Wachtwoord resetten mislukt: " + ex.Message);
            }
        }

       




    }
}
