﻿using Microsoft.AspNetCore.Mvc;

namespace WebApiTeam05.Controllers
{
    public class UsersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
