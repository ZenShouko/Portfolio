﻿using ClassLibTeam05.Business;
using ClassLibTeam05.Business.Entities;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace WebApiTeam05.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        [HttpGet("Locations")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult GetLocationZips()
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(ParkLocaties.GetAll()));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace); //Log me please
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("Prijzen")]
        public ActionResult GetPrices()
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(ProductPrijzen.GetGaragePrijzen()));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        /// Returns an object with all available sizes for a given Gemeente.
        /// <para>{"Gemeente": "Hasselt"}</para>
        /// </summary>
        /// <param name="body">Gemeente</param>
        /// <returns></returns>
        [HttpPost("Groottes")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult GetSizes([FromBody] object body)
        {
            ParkLocatie park;
            //Deserialize object
            try
            {
                park = JsonConvert.DeserializeObject<ParkLocatie>(body.ToString());
            }
            catch
            {
                return BadRequest("Failed to deserialize request object.");
            }

            //Can only receive either Gemeente or LocatieId
            if (!string.IsNullOrEmpty(park.Gemeente) && !string.IsNullOrEmpty(park.LocatieId))
            {
                return BadRequest("Kies tussen Gemeente of Locatie!!");
            }

            //Check if a valid gemeente was received
            //if (!DbProdActions.DoesGemeenteExist(park.Gemeente))
            //{
            //    return NotFound("Gemeente niet gevonden.");
            //}

            //Get a list with available sizes
            //LocatieCapaciteit totaalCapaciteit;
            try
            {
                if (!string.IsNullOrEmpty(park.Gemeente))
                    return Ok(JsonConvert.SerializeObject(LocatieCapaciteiten.GetSizesBasedOnGemeente(park.Gemeente)));
                else
                    return Ok(JsonConvert.SerializeObject(LocatieCapaciteiten.GetSizesBasedOnLocation(park.LocatieId)));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// Expects an object of type Product with a Type and Gemeente.
        /// </summary>
        /// <param name="body">(Type), (Gemeente)</param>
        /// <returns></returns>
        [HttpPost("Products")]
        public ActionResult GetProducts([FromBody] object body)
        {
            //List with all available types
            List<string> listTypeBoxes = new List<string>()
            {
                "Garage",
                "Container"
            };

            //Deserialize object
            Product product;
            try
            {
                product = JsonConvert.DeserializeObject<Product>(body.ToString());
            }
            catch (Exception)
            {
                return BadRequest("Failed to deserialize body.");
            }

            //Check if a valid gemeente/Type was received
            if (string.IsNullOrEmpty(product.Type) || string.IsNullOrEmpty(product.Gemeente))
                return BadRequest("Geen gemeente/type ontvangen.");
            if (!ParkLocaties.DoesGemeenteExist(product.Gemeente))
                return NotFound("Gemeente niet gevonden.");
            if (!listTypeBoxes.Contains(product.Type))
                return BadRequest("Geen geldige Type ontvangen.");

            //Get the correct catalogus
            try
            {
                switch (product.Type)
                {
                    case "Garage":
                        {
                            return Ok(JsonConvert.SerializeObject(ProductCatalogi.GetAllBasedOnGemeente(product.Gemeente)));
                        }
                    default: //Return error if type hasn't been implemented yet
                        {
                            return BadRequest("Type has not been implemented yet.");
                        }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost("ProductAvailability")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult GetProductAvailability([FromBody] object body)
        {
            ParkLocatie park; //Object to deserialize body to

            //Deserialize
            try
            {
                park = JsonConvert.DeserializeObject<ParkLocatie>(body.ToString());
            }
            catch
            {
                return BadRequest("Failed to deserialize request object.");
            }

            //LocatieID Check
            if (string.IsNullOrEmpty(park.LocatieId))
                return BadRequest("LocatieId niet ontvangen.");
            else if (!ParkLocaties.DoesLocationExist(park.LocatieId))
                return NotFound("Locatie niet gevonden.");

            //Handle Request
            try
            {
                return Ok(JsonConvert.SerializeObject(ProductAvailabilities.GetAvailabilities(park.LocatieId)));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost("ProductDetails")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult GetProductDetails([FromBody] object body)
        {
            Product product; //Object to deserialize body to
            //Deserialize
            try
            {
                product = JsonConvert.DeserializeObject<Product>(body.ToString());
            }
            catch
            {
                return BadRequest("Failed to deserialize request object.");
            }

            //LocatieID Check
            if (string.IsNullOrEmpty(product.Size))
                return BadRequest("Product Size niet ontvangen.");

            //Niet nodig, wordt automatisch bepaald in de functie
            //else if (!Producten.CheckProductId(product.ProductId))
            //    return NotFound("Product niet gevonden.");

            //Handle Request
            try
            {
                return Ok(JsonConvert.SerializeObject(Producten.GetArtikelOmschrijving(product)));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPut("NewOrder")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult CreateOrder([FromBody] List<object> body)
        {
            List<HuurPeriode> ordersList = new List<HuurPeriode>();
            //Deserialize
            try
            {
                foreach (var item in body)
                {
                    HuurPeriode huurPeriode = JsonConvert.DeserializeObject<HuurPeriode>(item.ToString());
                    ordersList.Add(huurPeriode);
                }
            }
            catch
            {
                return BadRequest("Failed to deserialize request object.");
            }

            //Handle Request
            try
            {
                foreach (HuurPeriode order in ordersList)
                {
                    HuurPeriodes.AddHuurPeriode(order);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

            return Ok();
        }
    }
}
