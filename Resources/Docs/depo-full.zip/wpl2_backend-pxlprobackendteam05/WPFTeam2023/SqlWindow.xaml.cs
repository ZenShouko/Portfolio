﻿using ClassLibTeam05;
using ClassLibTeam05.Business.Entities;
using System;
using System.Data;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows;
using System.Windows.Controls;
using WPFTeam2023.Properties;

namespace WPFTeam2023
{
    /// <summary>
    /// Interaction logic for SqlWindow.xaml
    /// </summary>
    public partial class SqlWindow : Window
    {
        public SqlWindow()
        {
            InitializeComponent();
            //Footer text
            TxtFooter.Text = $"[Ingelogd als {Settings.Default.VoorNaam}]";
            //Fill combobox
            FillTableCombobox();
        }

        private void FillTableCombobox()
        {
            string tableNames = "";
            try
            {
                tableNames = Database.GetTableNames();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kon tabellen niet ophalen.\n" +
                    ex.Message);
            }

            string[] tableName = tableNames.Split(';');

            foreach (string table in tableName)
            {
                CbTables.Items.Add(table);
            }
        }

        private void BtnGetData_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = Database.GetDataTable(CbTables.SelectedItem.ToString());
            DgdSql.ItemsSource = null;
            DgdSql.ItemsSource = dt.DefaultView;

            //SelectResult result = Students.GetStudents();
            //if (result.Succeeded)
            //{
            //    DgdSql.ItemsSource = null;
            //    DgdSql.ItemsSource = result.DataTable.DefaultView;
            //}
        }

        private void BtnLogUit_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Wilt u uitloggen?", "Afmelden", MessageBoxButton.YesNo, MessageBoxImage.Question)
                == MessageBoxResult.Yes)
            {
                RemoveUserData();
                ReturnToLoginWindow();
            }
        }

        private void RemoveUserData()
        {
            //Verwijder ID, naam en email
            Settings.Default.VoorNaam = "";
            Settings.Default.Email = "";
            Settings.Default.UserID = 0;
            Settings.Default.Save();
        }

        private void ReturnToLoginWindow()
        {
            //Ga terug naar login
            MainWindow window = new MainWindow();
            window.Show();
            Close();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            //Wie is de sender?
            MenuItem menuItem = (MenuItem)sender;

            //Wat is de header van de sender?
            switch(menuItem.Header.ToString())
            {
                case "Add Garage":
                    AddWindow window = new AddWindow(); 
                    window.ShowDialog(); break;
                case "Modify Table":
                    {
                        if (DgdSql.SelectedItem == null)
                        {
                            MessageBox.Show("Selecteer een rij om te wijzigen.", "Wijzigen", MessageBoxButton.OK, MessageBoxImage.Information);
                            return;
                        }

                        ModifyWindow modifWindow = new ModifyWindow((DataRowView)DgdSql.SelectedItem, CbTables.SelectedItem.ToString());
                        modifWindow.ShowDialog(); break;
                    }
                    default: break;
            }
        }
    }
}
