﻿using ClassLibTeam05.Business;
using ClassLibTeam05.Business.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WPFTeam2023
{
    /// <summary>
    /// Interaction logic for AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        public AddWindow()
        {
            InitializeComponent();

            //Determine on which device we are running
            ImageFolderPath = Environment.MachineName == "HINOKAMI_KAGURA" ?
                $@"{Properties.Resources.TargetFolderPc}" : $@"{Properties.Resources.TargetFolderLaptop}";
        }
        //Path to the folder where the images are stored
        string ImageFolderPath;

        //Image control
        private int imageCount = 0;
        private Dictionary<string, Image> imageDictionary = new Dictionary<string, Image>();

        #region Buttons
        private void BtnValidate_Click(object sender, RoutedEventArgs e)
        {
            if (!CheckGegevens())
            {
                MessageBox.Show("Gelieve alle velden correct in te vullen", "Foutmelding", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //Lock
            BtnValidate.IsEnabled = false;
            TopBorder.IsEnabled = false;
            TopBorder.BorderBrush = Brushes.Transparent;

            //Unlock
            BottomBorder.IsEnabled = true;
            BottomBorder.BorderBrush = Brushes.CadetBlue;
            BtnAdd.IsEnabled = true;
        }

        private void BtnBlader_Click(object sender, RoutedEventArgs e)
        {
            //Open dialog to select Image files
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            //Only accept JPG files
            dlg.Filter = "Image files (*.jpg) | *.jpg";
            dlg.Multiselect = true;

            //Show the dialog
            if (dlg.ShowDialog() == true)
            {
                string[] fileNames = dlg.FileNames;
                foreach (string name in fileNames)
                {
                    //Check the image count [MAX 5 afbeeldingen]
                    if (imageCount >= 5)
                    {
                        MessageBox.Show("U kan maximaal 5 afbeeldingen toevoegen", "Foutmelding", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    //Give the image a name
                    string imageName = $"{GenerateLocationId(TxtGemeente.Text)}-{imageCount + 1}.jpg";

                    //Change image name if it already exists
                    int c = 1;
                    while (imageDictionary.ContainsKey(imageName))
                    {
                        imageName = $"{GenerateLocationId(TxtGemeente.Text)}-{c}.jpg";
                        c++;
                    }

                    //Create a new image control
                    Image img = new Image();

                    //Set the source of the image control
                    BitmapImage bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri(name);
                    bitmap.EndInit();

                    //Set image source to the bitmap
                    img.Source = bitmap;

                    //[+] Add the image to the dictionary
                    imageDictionary.Add(imageName, img);

                    //Keep track of the image count
                    imageCount++;

                    //Add the images to the panel
                    DisplayNewImage(imageName, img);
                }
            }
        }

        private async void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            //Create Park object with the data from the fields
            Park park = new Park();
            park.LocatieId = GenerateLocationId(TxtGemeente.Text);
            park.Gemeente = TxtGemeente.Text;
            park.Postcode = int.Parse(TxtPostcode.Text);
            park.Adres = TxtAdres.Text;
            park.XS = int.Parse(TxtXs.Text);
            park.S = int.Parse(TxtS.Text);
            park.M = int.Parse(TxtM.Text);
            park.L = int.Parse(TxtL.Text);
            park.RegionalePrijs = int.Parse(TxtRegionale.Text);
            park.ImageNames = imageDictionary.Keys.ToList();

            //Add the park to the database
            try
            {
                await Parken.AddPark(park);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Foutmelding", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }

            //Save the images
            SaveImages();

            //Close the window
            MessageBox.Show($"{park.Gemeente} werd succesvol toegevoegd!");
            this.Close();
        }

        private void BtnOpnieuw_Click(object sender, RoutedEventArgs e)
        {
            //Verwijder alle afbeeldingen
            imageDictionary.Clear();
            ImagePanel.Children.Clear();
            imageCount = 0;
        }

        #endregion

        #region Methods
        private bool CheckGegevens()
        {
            //Returns true if all fields are correct
            //Check if all fields are filled in
            if (string.IsNullOrEmpty(TxtGemeente.Text) || string.IsNullOrEmpty(TxtPostcode.Text) ||
                string.IsNullOrEmpty(TxtAdres.Text) || string.IsNullOrEmpty(TxtXs.Text) ||
                string.IsNullOrEmpty(TxtS.Text) || string.IsNullOrEmpty(TxtM.Text) ||
                string.IsNullOrEmpty(TxtL.Text) || string.IsNullOrEmpty(TxtRegionale.Text))
            { return false; }

            //Check if the number textboxses have a valid number
            if (!int.TryParse(TxtPostcode.Text, out int postcode) || !int.TryParse(TxtXs.Text, out int xs) ||
                !int.TryParse(TxtS.Text, out int s) || !int.TryParse(TxtM.Text, out int m) ||
                !int.TryParse(TxtL.Text, out int l))
            { return false; }

            return true;
        }

        private string GenerateLocationId(string gemeente)
        {
            //Take the first, middle and last letter of the gemeente
            string firstLetter = gemeente.Substring(0, 1);
            string middleLetter = gemeente.Substring(gemeente.Length / 2, 1);
            string lastLetter = gemeente.Substring(gemeente.Length - 1, 1);

            //Concatinate the letters & Add [GemeenteCount] + 1
            return (firstLetter + middleLetter + lastLetter).ToUpper()
                + (GetCountGemeente(gemeente) + 1).ToString();
        }

        private int GetCountGemeente(string gemeente)
        {
            //Returns the count of the gemeente in GpLocatie
            return ParkLocaties.GetCountGemeente(gemeente);
        }

        #endregion

        #region Image Methods
        private void DisplayNewImage(string imgName, Image img)
        {
            //Create a stackpanel that contains the image and the image name
            //[Get the last image in the dictionary]

            //StackPanel
            StackPanel panel = new StackPanel();
            panel.HorizontalAlignment = HorizontalAlignment.Center;
            panel.VerticalAlignment = VerticalAlignment.Center;
            panel.Margin = new Thickness(5);
            panel.Cursor = Cursors.Pen;
            panel.MouseEnter += (s, e) => { panel.Background = Brushes.LightGray; };
            panel.MouseLeave += (s, e) => { panel.Background = Brushes.White; };
            panel.MouseDown += RemoveMe;

            //Image
            img.Width = 125;
            img.Height = 85;
            img.Stretch = Stretch.UniformToFill;
            img.Margin = new Thickness(5);

            //TextBlock
            TextBlock txt = new TextBlock();
            txt.HorizontalAlignment = HorizontalAlignment.Center;
            txt.TextDecorations = TextDecorations.Underline;
            txt.Text = imgName;


            //Add the controls to the stackpanel
            panel.Children.Add(img);
            panel.Children.Add(txt);

            //Finalementé
            ImagePanel.Children.Add(panel);
        }

        private void RemoveMe(object sender, MouseButtonEventArgs e)
        {
            //Get sender
            StackPanel panel = sender as StackPanel;

            //Get the image
            Image img = panel.Children[0] as Image;

            //Remove the image from the dictionary
            foreach (var pair in imageDictionary)
            {
                if (pair.Value.Equals(img))
                {
                    imageDictionary.Remove(pair.Key);
                    imageCount--;
                    break;
                }
            }

            //Remove childs from the panel
            panel.Children.Clear();

            //Remove the panel from ImagePanel
            ImagePanel.Children.Remove(panel);

            //Rearrange the imageNames
            //RearrangeImageNames();
        }

        private void SaveImages()
        {
            foreach (KeyValuePair<string, Image> imgPackage in imageDictionary)
            {
                string imageName = imgPackage.Key;
                Image img = imgPackage.Value;

                BitmapSource source = imgPackage.Value.Source as BitmapSource;

                //Create a new bitmap encoder
                JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                //Set the quality of the image
                encoder.QualityLevel = 100;
                //Frames
                encoder.Frames.Add(BitmapFrame.Create(source));

                //Save the image
                using (FileStream stream = new FileStream($@"{ImageFolderPath}\{imageName}", FileMode.Create))
                {
                    encoder.Save(stream);
                }
            }

            //Open the folder
            System.Diagnostics.Process.Start(ImageFolderPath);
        }

        #endregion

        //Test
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SaveImages();
        }
    }
}
