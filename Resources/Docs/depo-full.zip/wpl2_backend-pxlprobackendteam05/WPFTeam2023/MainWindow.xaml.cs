﻿using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using WPFTeam2023.Properties;
using ClassLibTeam05;
using ClassLibTeam05.Business;

namespace WPFTeam2023
{
    /// <summary>
    /// MainWindow is de login scherm.
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            //Is de gebruiker al ingelogd?
            if (Settings.Default.VoorNaam != "")
            {
                ShowNextWindow();
                return; //No need to initialize this window
            }

            InitializeComponent();
        }

        #region Connection Related
        private async void CheckConnection(object sender, RoutedEventArgs e)
        {
            UpdateUiBeforeConnectionAttempt();

            //Probeer een connectie uit te voeren.
            try
            {
               // await Task.Run(() => Database.CanConnectToServer());
                UpdateUiAfterConnectionAttempt(true);
            }
            catch (Exception ex)
            {
                UpdateUiAfterConnectionAttempt(false);
                MessageBox.Show("Verbinding met de server mislukt.\n\n" + ex.Message, "Connectie Fout",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateUiBeforeConnectionAttempt()
        {
            //Start progressbar
            PbConnection.Visibility = Visibility.Visible;
            PbConnection.IsIndeterminate = true;

            //Hide button
            BtnCheckConnection.Visibility = Visibility.Collapsed;

            //Display "Connecting" text
            TxtStatus.Text = "Connecting ...";
            TxtStatus.Foreground = Brushes.Black;
        }

        private void UpdateUiAfterConnectionAttempt(bool isConnected)
        {
            //Stop progressbar
            PbConnection.IsIndeterminate = false;
            PbConnection.Visibility = Visibility.Hidden;

            //Show Button again
            BtnCheckConnection.Visibility = Visibility.Visible;

            //Update TxtStatus depending on wether we're connected.
            if (isConnected)
            {
                TxtStatus.Text = "Server Running!";
                TxtStatus.Foreground = Brushes.Green;
            }
            else
            {
                TxtStatus.Text = "Server Down!";
                TxtStatus.Foreground = Brushes.Crimson;
            }
        }
        #endregion

        #region User Login Related
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               // Database.CanAdminLogIn(TxtEmail.Text, TxtWachtwoord.Password);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Oops");
                return;
            }

            SaveUserData();

            //Toon welkom bericht
            MessageBox.Show($"Log in succes! Hi {Settings.Default.VoorNaam}! 😁", "Messagi");

            //Log in
            ShowNextWindow();
        }

        private protected void SaveUserData()
        {
            //Retrieve & Save user data
            string userData = ""; //Database.GetUserData(TxtEmail.Text);
            string[] splitData = userData.Split(';');
            Settings.Default.UserID = int.Parse(splitData[0]);
            Settings.Default.Email = splitData[1];
            Settings.Default.VoorNaam = splitData[2];
            Settings.Default.Save();
        }

        private void ShowNextWindow()
        {
            SqlWindow window = new SqlWindow();
            window.Show();
            Close();
        }
        #endregion

        #region Miscellaneous
        private void TxtEmail_GotFocus(object sender, RoutedEventArgs e)
        {
            //Basically placeholder
            if (TxtEmail.Text == "naam.achternaam@student.pxl.be")
            {
                TxtEmail.Clear();
                TxtEmail.Foreground = Brushes.Black;
            }
        }

        private void TxtEmail_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtEmail.Text))
            {
                TxtEmail.Text = "naam.achternaam@student.pxl.be";
                TxtEmail.Foreground = Brushes.Gray;
            }
        }

        private void TxtEmail_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            //Only activate if [@] has been pressed.
            if (e.Key != Key.D2) { return; }

            //Check hoeveel [@] er voorkomen in txtemail
            int atCount = 0;
            foreach(char c in TxtEmail.Text)
            {
                if (c == '@')
                {
                    atCount++;
                }
            }

            //Add auto completion [student.pxl.be]
            if (atCount == 1)
            {
                //Save current selection
                int selectionStart = TxtEmail.SelectionStart;

                //Add auto completion
                TxtEmail.Text += "student.pxl.be";

                //Select the auto completion
                TxtEmail.SelectionStart = selectionStart;
                TxtEmail.SelectionLength = "student.pxl.be".Length;
                
                //Mark Handled (?)
                e.Handled = true;
            }
        }
        #endregion
    }
}