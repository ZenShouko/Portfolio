﻿using ClassLibTeam05.Business;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WPFTeam2023
{
    /// <summary>
    /// Interaction logic for ModifyWindow.xaml
    /// </summary>
    public partial class ModifyWindow : Window
    {
        //Row in question
        private DataRowView rowInQuestion = null; //To display row
        private DataTable newDataTable = new DataTable(); //To display changes
        private string tableName = "";
        private List<SqlCommand> commands = new List<SqlCommand>();
        public ModifyWindow(DataRowView row, string tableName)
        {
            InitializeComponent();
            rowInQuestion = row;
            this.tableName = tableName;
            DisplayRowIQ();
        }

        #region Prep
        private void DisplayRowIQ()
        {
            //Create table
            DataTable dt = new DataTable();

            //Add columns
            foreach (DataColumn col in rowInQuestion.Row.Table.Columns)
            {
                //Default table
                dt.Columns.Add(col.ColumnName, col.DataType);

                //New table
                newDataTable.Columns.Add(col.ColumnName, col.DataType);

                //Add columns to combobox
                CboxColumns.Items.Add(col.ColumnName);
            }

            //Add row
            dt.ImportRow(rowInQuestion.Row);
            newDataTable.ImportRow(rowInQuestion.Row);

            //Display
            GboxTable.Header = tableName + " tabel:";
            DgRow.ItemsSource = dt.DefaultView;
            DgNewRow.ItemsSource = newDataTable.DefaultView;

            //Remove first row from combobox (PK)
            CboxColumns.Items.RemoveAt(0);
        }
        #endregion

        #region Events
        private string GetDataType()
        {
            //CheckOrder[Date] > [Int32] => [String]
            if (int.TryParse(TxtNewValue.Text, out int number))
            {
                return "System.Int32";
            }
            else //Default
            {
                return "System.String";
            }
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            //Zijn velden correct ingevuld?
            if (!CheckInput())
            {
                return;
            }

            //What is the selected columns datatype?
            string dataType = GetDataType();

            //Convert TxtNewValue to datatype
            object newValue = TxtNewValue.Text;
            switch (dataType)
            {
                case "System.String":
                    newValue = TxtNewValue.Text;
                    break;
                case "System.Int32":
                    newValue = Convert.ToInt32(TxtNewValue.Text);
                    break;
                default:
                    MessageBox.Show("Kon Data type not opvangen.", "Fout");
                    return;
            }


            //Create query
            string query = $"UPDATE {tableName} " +
                $"SET {CboxColumns.SelectedItem} = @newValue " +
                $"WHERE {rowInQuestion.Row.Table.Columns[0].ColumnName} = @PKValue;";

            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@newValue", newValue);
            cmd.Parameters.AddWithValue("@PKValue", rowInQuestion.Row[0]);

            //Add query to list
            commands.Add(cmd);

            //Update newDataTable
            newDataTable.Rows[0][CboxColumns.SelectedItem.ToString()] = newValue;

            //Display newDataTable
            DgNewRow.ItemsSource = null;
            DgNewRow.ItemsSource = newDataTable.DefaultView;

            //Count changes
            CountChanges();

            //Highlight modified cell
            HighlightColumn(DgNewRow);
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Weet u zeker dat u wilt annuleren?", "Annuleren", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }

        private async void BtnApply_ClickAsync(object sender, RoutedEventArgs e)
        {
            //Send all queries to database
            try
            {
                await Parken.Modify(commands);
                MessageBox.Show("Succes!");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Er is iets misgegaan.\n" + ex.Message, "Fout");
            }
        }
        #endregion


        #region Miscellanious
        private void CboxColumns_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            HighlightColumn(DgRow);
        }

        private void HighlightColumn(DataGrid dg)
        {
            string selectedColumn = CboxColumns.SelectedItem.ToString();
            //Reset all cell styles, only for dgRow
            if (dg == DgRow)
            {
                foreach (DataGridColumn colls in dg.Columns)
                {
                    colls.CellStyle = null;
                }
            }

            //Find selected column
            DataGridColumn col = dg.Columns.FirstOrDefault(c => c.Header.ToString() == selectedColumn);

            //Set style for selected column, first entry
            if (col != null)
            {
                Style style = new Style(typeof(DataGridCell));
                style.Setters.Add(new Setter(BackgroundProperty, Brushes.Purple));
                style.Setters.Add(new Setter(ForegroundProperty, Brushes.White));
                style.Setters.Add(new Setter(FontWeightProperty, FontWeights.Bold));
                col.CellStyle = style;
            }

            //Scroll to column in question
            dg.ScrollIntoView(dg.Items[0], col);
        }

        private bool CheckInput()
        {
            //Check if input is correct
            if (CboxColumns.SelectedIndex == -1)
            {
                MessageBox.Show("Selecteer een kolom.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(TxtNewValue.Text))
            {
                MessageBox.Show("Vul een waarde in.");
                return false;
            }

            return true;
        }

        private void CountChanges()
        {
            int count = 0;
            foreach (var item in commands)
            {
                count++;
            }

            TxtChanges.Text = count.ToString();

            //Change color if changes are > 0
            TxtChanges.Foreground = count > 0 ? Brushes.Purple : Brushes.Black;
        }
        #endregion

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Weet u zeker dat u deze rij wilt verwijderen? Dit kan niet ongedaan worden.", "Verwijderen", MessageBoxButton.YesNo)
                == MessageBoxResult.No)
                return;

            //Create query
            string query = $"DELETE {tableName} WHERE {rowInQuestion.Row.Table.Columns[0].ColumnName} = @value";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@value", rowInQuestion.Row[0]);

            //Add query to list
            commands.Clear();
            commands.Add(cmd);

            //Send delete query to database
            try
            {
                Parken.Modify(commands);
                MessageBox.Show($"{rowInQuestion.Row[0]} is verwijderd!", "Succes");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
