﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace ClassLibTeam05
{
    public static class Database
    {
        private static string ConnectionString = "Server=10.128.4.7;Database=Db2023Team05;User Id=PxlUserT05;Password=PxlUserT05;";

        public static SqlConnection GetSqlConnection()
        {
            SqlConnection connection = new SqlConnection(ConnectionString);

            try
            {
                connection.Open();
            }
            catch (Exception ex)
            {
                connection.Close();
                throw new Exception(ex.Message);
            }

            return connection;
        }

        public static DataTable GetDataTable(string tableName)
        {
            using (SqlConnection connection = GetSqlConnection())
            {
                SqlCommand command = new SqlCommand($"SELECT * FROM {tableName}", connection);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                return dataTable;
            }
        }

        public static string GetUserDetails(int id)
        {
            using (SqlConnection connection = GetSqlConnection())
            {
                SqlCommand command = new SqlCommand("SELECT * FROM Gebruikers where GebruikerId = @ID;", connection);
                command.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = command.ExecuteReader();
                string info = "";

                while (!reader.Read())
                {
                    info += reader.ToString();
                }

                reader.Close();

                return info;
            }

            throw new Exception("BRUH");
        }

        /// <summary>
        /// Controleert of een connectie naar de database mogelijk is. Indien het faalt, gooit het een exception.
        /// <para>
        /// Roep method op als: [ await Task.Run(() => CanConnectToServer()) ] in een try catch expression.
        /// </para>
        /// </summary>
        /// <exception cref="Exception"></exception>
        public static async Task CanConnectToServer()
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    //connection.OpenAsync();
                    connection.Open();
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

        }

        /// <summary>
        /// Returns [UserId] [Email] [Voornaam] as a string.
        /// <para>String format: "99;email@email.com;John"</para>
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static string GetUserData(string email)
        {
            string userData = "";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                }
                catch
                {
                    throw new Exception($"Could not connect to server.");
                }

                //Retrieve UserId
                string query = "SELECT GebruikerID FROM Gebruikers where Email = @Email;";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    userData += ((string)cmd.ExecuteScalar().ToString() + ";");
                }

                //Retrieve Email [Dit is om de email in een correcte formaat te verkrijgen]
                query = "SELECT Email FROM Gebruikers where Email = @Email;";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    userData += ((string)cmd.ExecuteScalar() + ";");
                }

                //Retrieve Voornaam
                query = "SELECT voorNaam FROM Gebruikers where Email = @Email;";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Email", email); 
                    userData += ((string)cmd.ExecuteScalar() + ";");
                }

                //Retrieve AchterNaam
                query = "SELECT AchterNaam From Gebruikers where Email = @Email;";
                using (SqlCommand cmd = new SqlCommand(query,connection))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    userData += ((string)cmd.ExecuteScalar());
                }

                return userData;
            }
        }

        public static string UpdateUserData(string email)
        {
            string userData = "";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                }
                catch
                {
                    throw new Exception($"Could not connect to server.");
                }

                //Nieuwe Wachtwoord [Dit is om de email in een correcte formaat te verkrijgen]
                string query = "UPDATE Gebruikers SET Wachtwoord = @NewPassword where Email = @Email;";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    userData += ((string)cmd.ExecuteScalar() + ";");
                }

                //Nieuwe Achternaam
                query = "UPDATE Gebruikers SET Achternaam = @NewAchternaam where Email = @Email;";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    userData += ((string)cmd.ExecuteScalar() + ";");
                }

                //Nieuwe VoorNaam
                query = "UPDATE Gebruikers SET Voornaam = @NewVoornaam where Email = @Email; ";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    userData += ((string)cmd.ExecuteScalar());
                }

                return userData;
            }
        }

        /// <summary>
        /// Returns a string with all table names.
        /// <para>
        /// String format: "Table1;Table2;Table3;"
        /// </para>
        /// </summary>
        /// <returns></returns>
        public static string GetTableNames()
        {
            string tableNames = "";

            //Connect
            using (SqlConnection connection = GetSqlConnection())
            {
                //Retrieve the table names using SqlCommand and add them to a SqlDataReader object
                SqlCommand command = new SqlCommand("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'\r\nAND TABLE_NAME != 'sysdiagrams';", connection);
                SqlDataReader reader = command.ExecuteReader();

                //Loop through the table names and add them
                while (reader.Read())
                {
                    tableNames += reader["TABLE_NAME"].ToString() + ";";
                }

                //Close everything
                reader.Close();
            }

            //Remove the last ";"
            tableNames = tableNames.Substring(0, tableNames.Length - 1);

            return tableNames;
        }

        #region UserLogin

        /// <summary>
        /// Controleert op email, wachtwoord en Admin machtigingen.
        /// <para/>
        /// [Admins Only]
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <exception cref="Exception"></exception>
        public static void CanAdminLogIn(string email, string password)
        {
            //Check for valid userinputs
            try
            {
                CheckValidInput(email, password);
                CheckEmailExistence(email);
                CheckPassword(email, password);
                CheckUserRole(email);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Controleert op email en wachtwoord.
        /// <para/>
        /// [Open For Every User]
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <exception cref="Exception"></exception>
        public static void UserLogIn(string email, string password)
        {
            //Check for valid userinputs
            try
            {
                CheckValidInput(email, password);
                CheckEmailExistence(email);
                CheckPassword(email, password);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private static void CheckValidInput(string email, string password)
        {
            ///Controleert voor de basic inputs.
            /// - Zijn alle gegevens ingevuld?
            /// - Bevat email een [@] en [.]
            /// - Is wachtwoord langer dan 5 characters lang?

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                throw new Exception("Er is geen Email of Wachtwoord ingevuld (?) 🤦‍♂️");
            }
            //Email bevat geen @ of .
            else if (!email.Contains("@") || !email.Contains("."))
            {
                throw new Exception("Email voldoet niet aan de email criteria. 😑");
            }
            //Wachtwoord is korter dan 5 karakters
            else if (password.Length < 5)
            {
                throw new Exception("Systeem heeft geen goesting om wachtwoorden korter dan 5 karakters te controleren. Als uw wachtwoord korter is dan 5 karakters, dan pech 😋");
            }
        }

        public static void CheckEmailExistence(string email)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                //Open connectie [Try catch om crashes te voorkomen]
                try
                {
                    connection.Open();
                }
                catch (Exception ex)
                {
                    throw new Exception("Er is een fout opgetreden tijdens het connecteren.\n\n" + ex.Message);
                }

                //Construct SQL Query [Selecteert hoeveel keer het opgegeven email voorkomt]
                string emailQuery = $"SELECT COUNT(*) FROM Gebruikers WHERE Email = @Email";
                SqlCommand command = new SqlCommand(emailQuery, connection);
                command.Parameters.AddWithValue("@Email", email);

                //Voer Query uit
                int count = (int)command.ExecuteScalar();

                //Check
                if (count == 0)
                {
                    throw new Exception($"De opgegeven email [ {email} ] kon niet gevonden worden in de database. 😶‍🌫️");
                }
                //FOUT Als de email 2x voorkomt. [Dit kan niet!]
                else if (count > 1)
                {
                    //De database kan geen 2 dezelfde emails bevatten. DUS ALS DIT VOORKOMT DAN HEBBEN WE EEN GROOT PROBLEEM!!
                    throw new Exception($"De opgegeven email [ {email} ] kwam {count} keer voor in de database.");
                }
               
            }

        }

      


        private static void CheckPassword(string email, string password)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                }
                catch (Exception ex)
                {
                    throw new Exception("Er is een fout opgetreden tijdens het connecteren.\n\n" + ex.Message);
                }

                //Check als de wachtwoord correct is
                string query = $"SELECT Wachtwoord FROM Gebruikers WHERE Email = @Email;";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", email);

                string correctPassword = (string)command.ExecuteScalar();

                if (String.Compare(password, correctPassword, StringComparison.CurrentCulture) != 0)
                {
                    throw new Exception("Onjuist wachtwoord. 😠");
                }
            }
        }

        private static void CheckUserRole(string email)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                }
                catch (Exception ex)
                {
                    throw new Exception("Er is een fout opgetreden tijdens het connecteren.\n\n" + ex.Message);
                }

                //Is er gebruiker een admin?
                string query = $"SELECT Machtiging FROM Gebruikers WHERE Email = @Email;";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", email);
                string machtiging = command.ExecuteScalar().ToString();

                if (machtiging.ToString() != "Admin")
                {
                    throw new Exception("U bent geen admin. GEEN TOEGANG DUS!! 😠");
                }
            }
        }
        #endregion
    }
}
