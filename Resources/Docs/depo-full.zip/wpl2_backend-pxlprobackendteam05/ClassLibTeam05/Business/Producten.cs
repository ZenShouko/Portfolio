﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business
{
    public static class Producten
    {
        public static Product GetArtikelOmschrijving(Product prod)
        {
            return new ProductData().GetOmschrijving(prod);
        }

        public static bool CheckProductId(string productId)
        {
            return new ProductData().CheckProductId(productId);
        }
    }
}
