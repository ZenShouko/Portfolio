﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClassLibTeam05.Business
{
    public static class HuurPeriodes
    {
        public static List<HuurPeriode> GetHuurPeriodes(string locatieId)
        {
            return new HuurPeriodeData().GetHuurPeriodes(locatieId);
        }

        public static DateTime GetFirstRetourDate(string locatieId, string productId)
        {
            return new HuurPeriodeData().GetFirstRetourDate(locatieId, productId);
        }

        public static void AddHuurPeriode(HuurPeriode huurPeriode)
        {
            if (!new HuurPeriodeData().CreateOrder(huurPeriode))
            {
                throw new Exception("Failed");
            }
        }

        public static int GetNextGarageNr(string productId, string locatieId)
        {
            return new HuurPeriodeData().GetNextGarageNr(locatieId, productId);
        }
    }
}
