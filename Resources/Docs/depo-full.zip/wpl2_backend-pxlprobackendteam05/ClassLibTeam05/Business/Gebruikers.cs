﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data;
using ClassLibTeam05.Data.Framework;
using ClassLibTeam05.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business
{
    public static class Gebruikers
    {
        public static IEnumerable<Gebruiker> List()
        {
            return GebruikerRepository.GebruikerList;
        }

        public static void Add( string email, string matchiging, DateTime aanmaakDatum, string voornaam, string achternaam, string wachtwoord, string telefoonNummer, string postcode, string gemeente, string adres1, string adres2)
        {
            GebruikerRepository.Add(email, matchiging, aanmaakDatum, voornaam, achternaam, wachtwoord,telefoonNummer, postcode, gemeente, adres1, adres2);

        }

        public static SelectResult GetGebruikers()
        {
            GebruikerData gebruikerData= new GebruikerData();
            SelectResult result = gebruikerData.Select();
            return result;

        }
        public static InsertResult AddGebruiker(Gebruiker gebruiker)
        {
            GebruikerData gebruikerData = new GebruikerData();
            InsertResult result = gebruikerData.Insert(gebruiker);

            return result;
        }


        /*
        public static InsertResult AddGebruiker(string email, string machtiging, DateTime aanmaakDatum, string voornaam, string achternaam, string wachtwoord, string telefoonNummer, string postcode, string gemeente, string adresRegel1, string adresRegel2)
        {
            Gebruiker gebruiker =new Gebruiker();
          
            gebruiker.Email = email;
            gebruiker.Machtiging = machtiging;
            gebruiker.AanmaakDatum = aanmaakDatum;
            gebruiker.Voornaam = voornaam;
            gebruiker.Achternaam = achternaam;
            gebruiker.Wachtwoord= wachtwoord;
            gebruiker.TelefoonNummer= telefoonNummer;
            gebruiker.Postcode= postcode;
            gebruiker.Gemeente= gemeente;
            gebruiker.AdresRegel1 = adresRegel1;
            gebruiker.AdresRegel2 = adresRegel2;
            

            GebruikerData gebruikerData = new GebruikerData();
            InsertResult result = gebruikerData.Insert(gebruiker);

            return result;
        }
        */
    }
}
