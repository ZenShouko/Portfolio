﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business
{
    public static class LocatieCapaciteiten
    {
        public static LocatieCapaciteit GetSizesBasedOnGemeente(string gemeente)
        {
            return new LocatieCapaciteitData().GetSumSizes(gemeente);
        }

        public static LocatieCapaciteit GetSizesBasedOnLocation(string id)
        {
            return new LocatieCapaciteitData().CreateNewLocatieCapaciteit(id);
        }

        public static LocatieCapaciteit GetInUseBasedOnLocation(string id)
        {
            return new LocatieCapaciteitData().CreateNewInUseCapaciteit(id);
        }
    }
}
