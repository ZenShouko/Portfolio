﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Navigation;

namespace ClassLibTeam05.Business
{
    public static class ParkLocaties
    {
        public static List<ParkLocatie> GetAll()
        {
            return new ParkLocatieData().GetAll();
        }

        public static List<string> GetAllLocationIDs(string gemeente)
        {
            return new ParkLocatieData().GetLocationIDs(gemeente);
        }

        public static bool DoesGemeenteExist(string gemeente)
        {
            return new ParkLocatieData().CheckGemeentesExistance(gemeente);
        }

        public static bool DoesLocationExist(string ID)
        {
            return new ParkLocatieData().CheckLocatieExistance(ID);
        }

        public static int GetCountGemeente(string gemeente)
        {
            return new ParkLocatieData().GetCountGemeente(gemeente);
        }

        public static void AddParkLocatie(string gemeente, int postcode)
        {
            new ParkLocatieData().AddParkLocatie(gemeente, postcode);
        }
    }
}
