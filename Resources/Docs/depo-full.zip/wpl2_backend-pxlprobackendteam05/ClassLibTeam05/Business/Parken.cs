﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business
{
    public static class Parken
    {
        public static Task AddPark(Park park)
        {
            ParkData.AddPark(park);
            return Task.CompletedTask;
        }

        public static Task Modify(List<SqlCommand> commands)
        {
            ParkData.Modify(commands);
            return Task.CompletedTask;
        }
    }
}
