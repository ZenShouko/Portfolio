﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business.Entities
{
    public class Gebruiker
    {
        public int GebruikerId { get; set; }
        public string Machtiging { get; set; } = "User"; 
        public DateTime AanmaakDatum { get; set; } = DateTime.Now;
        public string Email { get; set; }
        public string VoorNaam { get; set; }
        public string AchterNaam { get; set; }
        public string Wachtwoord { get; set; }
        public string TelefoonNummer { get; set; }
        public string Postcode { get; set; }
        public string Gemeente { get; set; }
        public string AdresRegel1 { get; set; }
        public string AdresRegel2 { get; set; }
    }
}
