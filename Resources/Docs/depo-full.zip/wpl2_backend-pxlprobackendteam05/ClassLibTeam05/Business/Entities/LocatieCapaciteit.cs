﻿namespace ClassLibTeam05.Business.Entities
{
    public class LocatieCapaciteit
    {
        public string LocatieId { get; set; }
        public int XS { get; set; }
        public int S { get; set; }
        public int M { get; set; }
        public int L { get; set; }

        public LocatieCapaciteit() { }
    }
}
