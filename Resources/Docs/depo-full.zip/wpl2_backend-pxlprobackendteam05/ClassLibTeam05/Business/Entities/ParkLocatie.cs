﻿using System.CodeDom;
using System.Data.SqlClient;

namespace ClassLibTeam05.Business.Entities
{
    public class ParkLocatie
    {
        public string LocatieId { get; set; }
        public int Postcode { get; set; }
        public string Gemeente { get; set; }
        public ParkLocatie()
        {

        }
    }
}
