﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business.Entities
{
    public class HuurPeriode
    {
        //Based on the location
        public string LocatieId { get; set; } 
        public string ProductId { get; set; } 
        public int GebruikerId { get; set; }
        public DateTime StartDatum { get; set; } 
        public DateTime EindDatum { get; set; }
        public int AantalMaanden { get; set; }
        public int ProductNR { get; set; }
        public int Amount { get; set; }

        public HuurPeriode()
        {
            
        }
    }
}
