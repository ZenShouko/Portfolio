﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business.Entities
{
    public class ProductPrijs
    {
        public string ProductID { get; set; }
        public int Huurprijs { get; set; }
        public int ServiceKosten { get; set; }
        public int EnergieKosten { get; set; }
        public int Waarborg { get; set; }
        public int AdministratieKosten { get; set; }
        public string Grootte { get; set; }
    }
}
