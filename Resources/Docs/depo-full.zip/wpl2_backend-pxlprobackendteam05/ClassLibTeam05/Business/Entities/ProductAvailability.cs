﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business.Entities
{
    public class ProductAvailability
    {
        public string ProductId { get; set; }
        public string Size { get; set; }
        public string LocationId { get; set; }
        public bool IsAvailable { get; set; }
        public DateTime AvailableDate { get; set; } //The first date that the product is available
        public int Amount { get; set; } //The amount of products available
    }
}
