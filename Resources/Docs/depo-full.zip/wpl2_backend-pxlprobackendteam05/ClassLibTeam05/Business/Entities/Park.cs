﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business.Entities
{
    public class Park
    {
        //Ligging
        public string LocatieId { get; set; }
        public string Gemeente { get; set; }
        public int Postcode { get; set; }
        public string Adres { get; set; }

        //Capaciteit
        public int XS { get; set; }
        public int S { get; set; }
        public int M { get; set; }
        public int L { get; set; }

        //Prijs
        public int RegionalePrijs { get; set; }

        //Afbeeldingen
        public List<string> ImageNames { get; set; }
    }
}
