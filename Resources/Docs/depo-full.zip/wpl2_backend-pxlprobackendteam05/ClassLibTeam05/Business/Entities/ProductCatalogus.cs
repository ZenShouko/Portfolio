﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

///<summary>
///Dit classe bevat the hoofzaken die nodig zijn voor het product catalogus
///Dit is de compacte weergave niet de gedetaileerde.
///BV: Er word maar 1 afbeelding getoond en niet alle afbeeldingen van de locatie omdat
///we alleen een korte overzicht willen geven.
///</summary>
namespace ClassLibTeam05.Business.Entities
{
    public class ProductCatalogus
    {
        public string LocatieId { get; set; }
        public string Gemeente { get; set; }
        public string Adres { get; set; }
        public int Postcode { get; set; }
        public List<string> ListImageNames { get; set; }
        public int RegionalePrijs { get; set; }

        public ProductCatalogus() { }
    }
}
