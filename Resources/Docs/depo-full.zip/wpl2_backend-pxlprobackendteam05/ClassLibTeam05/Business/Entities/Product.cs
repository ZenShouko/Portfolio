﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Business.Entities
{
    public class Product
    {
        /// <summary>
        /// Garage of Container?
        /// Word gebruikt om te bepalen welke view er moet worden getoond.
        /// </summary>
        public string Type { get; set; }
        public string Gemeente { get; set; }
        public string ProductId { get; set; }
        public string Size { get; set; }
        public string Omschrijving { get; set; }
    }
}
