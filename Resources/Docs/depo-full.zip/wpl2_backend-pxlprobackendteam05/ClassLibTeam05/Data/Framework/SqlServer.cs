﻿using ClassLibTeam05.Business.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Data.Framework
{
    public class SqlServer
    {
        SqlConnection connection;
        SqlDataAdapter adapter;

        public SqlServer()
        {
            connection = new SqlConnection(Settings.GetConnectionString());
        }

        //SelectResult
        protected SelectResult Select(SqlCommand selectCommand)
        {
            var result = new SelectResult();

            try
            {
                SafetyMeasures();

                //Open Connection
                using (connection)
                {
                    selectCommand.Connection = connection;
                    connection.Open();

                    adapter = new SqlDataAdapter(selectCommand);
                    result.DataTable = new System.Data.DataTable();
                    adapter.Fill(result.DataTable);
                }
                //Let them know it succeeded
                result.Succeeded = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                result.AddError(ex.Message);
            }

            return result;
        }

        private void SafetyMeasures()
        {
            if (string.IsNullOrEmpty(connection.DataSource))
            {
                connection = new SqlConnection(Settings.GetConnectionString());
                Console.WriteLine("[!] #Connection.DataSource was Empty. Had to take Safety-Measures!");
            }
        }

        protected SelectResult Select(string tableName)
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = $"SELECT * FROM {tableName}";
            return Select(command);
        }


        //InsertResult
        protected InsertResult InsertRecord(SqlCommand insertCommand)
        {
            InsertResult result = new InsertResult(); 
            try 
            { 
                using (connection) 
                {
                    insertCommand.CommandText += "SET @new_id = SCOPE_IDENTITY();"; 
                    insertCommand.Parameters.Add("@new_id", SqlDbType.Int).Direction = ParameterDirection.Output; 
                    insertCommand.Connection = connection; 
                    connection.Open(); 
                    insertCommand.ExecuteNonQuery(); 
                    int newId = Convert.ToInt32(insertCommand.Parameters["@new_id"].Value); 
                    result.NewId = newId; 
                    connection.Close();
                } 
            } 
            catch (Exception ex) 
            { 
                throw new Exception(ex.Message); 
            }
            return result;
        }

        protected InsertResult Insert(SqlCommand cmd)
        {
            InsertResult result = new InsertResult(); 
            try
            {
                SafetyMeasures(); 
                using (connection)
                {
                    cmd.Connection = connection; 
                    connection.Open(); 
                    cmd.ExecuteNonQuery(); 
                } 
                result.Succeeded = true; 
            } 
            catch (Exception ex)
            {
                result.AddError(ex.Message);
                result.Succeeded = false;
            }
            return result; 
        }
     }
}
