﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace ClassLibTeam05.Data.Framework
{
    static class Settings
    {
        public static string GetConnectionString()
        {
            string serverName = "10.128.4.7";
            string databaseName = "Db2023Team05";
            string userId = "PxlUserT05";
            string password = "PxlUserT05";
            string connectionString = $"Server = {serverName};Database={databaseName};User Id={userId};Password={password};";
            return connectionString;
        }

       
        /*
        public static string GetConnectionString()
        {
            //string connectionString= "Trusted_Connection=True;";
            string connectionString = "user id = sa;";
            connectionString += "Password = pxl;";
            connectionString += $@"Server=VIVOBOOK15-EMRE\SQLEXPRESS;";
            connectionString += $"Database=DB_Emre";
            return connectionString;
        }
        */
    }
}
