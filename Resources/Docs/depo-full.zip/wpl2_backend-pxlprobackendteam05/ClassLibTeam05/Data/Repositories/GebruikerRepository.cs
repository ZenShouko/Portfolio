﻿using ClassLibTeam05.Business.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Data.Repositories
{
    static class GebruikerRepository
    {
        static GebruikerRepository()
        {
            GebruikerList = new List<Gebruiker>();
        }

        public static List<Gebruiker> GebruikerList { get; set; }
        public static void Add(string email, string machtiging, DateTime aanmaakDatum, string voornaam, string achternaam, string wachtwoord, string telefoonNummer, string postcode, string gemeente, string adres1, string adres2)
        {
            Gebruiker gebruiker= new Gebruiker();
            
            gebruiker.Email = email;
            gebruiker.Machtiging = machtiging;
            gebruiker.AanmaakDatum = aanmaakDatum;
            gebruiker.VoorNaam= voornaam;
            gebruiker.AchterNaam= achternaam;
            gebruiker.Wachtwoord= wachtwoord;
            gebruiker.TelefoonNummer= telefoonNummer;
            gebruiker.Postcode= postcode;
            gebruiker.Gemeente= gemeente;
            gebruiker.AdresRegel1= adres1;
            gebruiker.AdresRegel2= adres2;
            Add(gebruiker);
        }

        private static void Add(Gebruiker gebruiker)
        {
            GebruikerList.Add(gebruiker);
        }
    }
}
