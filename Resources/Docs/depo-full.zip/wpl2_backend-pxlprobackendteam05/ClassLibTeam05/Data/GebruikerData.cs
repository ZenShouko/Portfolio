﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;

namespace ClassLibTeam05.Data
{
    public class GebruikerData : SqlServer
    {
        public GebruikerData()
        {
            TableName = "Gebruikers";
        }
        public string TableName { get; set; }

        public SelectResult Select()
        {
            return base.Select(TableName);
        }

        public InsertResult Insert(Gebruiker gebruiker)
        {
            var result = new InsertResult();

            try
            {//SQL Command
                using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
                {
                    StringBuilder insertQuery = new StringBuilder();
                    insertQuery.Append($"Insert INTO {TableName} ");
                    insertQuery.Append($"(Email, Machtiging, Aanmaakdatum, Voornaam, Achternaam, Wachtwoord, TelefoonNummer, Postcode, Gemeente, AdresRegel1, AdresRegel2) VALUES ");
                    insertQuery.Append($"(@email,@machtiging, @aanmaakDatum, @voornaam, @achternaam, @wachtwoord, @telefoonnummer, @postcode, @gemeente, @adresRegel1, @adresRegel2); ");

                    using (SqlCommand insertCommand = new SqlCommand(insertQuery.ToString(), connection))
                    {
                        insertCommand.Parameters.Add("@email", System.Data.SqlDbType.VarChar).Value = gebruiker.Email;
                        insertCommand.Parameters.Add("@machtiging", System.Data.SqlDbType.VarChar).Value = gebruiker.Machtiging;
                        insertCommand.Parameters.Add("@aanmaakDatum", System.Data.SqlDbType.DateTime).Value = gebruiker.AanmaakDatum;
                        insertCommand.Parameters.Add("@voornaam", System.Data.SqlDbType.VarChar).Value = gebruiker.VoorNaam;
                        insertCommand.Parameters.Add("@achternaam", System.Data.SqlDbType.VarChar).Value = gebruiker.AchterNaam;
                        insertCommand.Parameters.Add("@wachtwoord", System.Data.SqlDbType.VarChar).Value = gebruiker.Wachtwoord;
                        insertCommand.Parameters.Add("@telefoonNummer", System.Data.SqlDbType.VarChar).Value = gebruiker.TelefoonNummer;
                        insertCommand.Parameters.Add("@postcode", System.Data.SqlDbType.VarChar).Value = gebruiker.Postcode;
                        insertCommand.Parameters.Add("@gemeente", System.Data.SqlDbType.VarChar).Value = gebruiker.Gemeente;
                        insertCommand.Parameters.Add("@adresRegel1", System.Data.SqlDbType.VarChar).Value = gebruiker.AdresRegel1;
                        insertCommand.Parameters.Add("@adresRegel2", System.Data.SqlDbType.VarChar).Value = gebruiker.AdresRegel2;
                       
                        connection.Open();
                        //result = InsertRecord(insertCommand);
                        insertCommand.ExecuteNonQuery();

                    }
                }                  
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            return result;


        }
        public static void UpdateGebruikerInDatabase(Gebruiker gebruiker)
        {
            using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
            {
                string query = "UPDATE Gebruikers SET " +                           
                               "Email = @email, " +
                               "Voornaam = @voornaam, " +
                               "Achternaam = @achternaam, " +
                               "Wachtwoord = @wachtwoord " +                             
                               "WHERE GebruikerId = @id";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    //command.Parameters.AddWithValue("@machtiging", gebruiker.Machtiging);
                    //command.Parameters.AddWithValue("@aanmaakDatum", gebruiker.AanmaakDatum);
                    command.Parameters.AddWithValue("@id", gebruiker.GebruikerId);
                    command.Parameters.AddWithValue("@email", gebruiker.Email);
                    command.Parameters.AddWithValue("@voornaam", gebruiker.VoorNaam);
                    command.Parameters.AddWithValue("@achternaam", gebruiker.AchterNaam);
                    command.Parameters.AddWithValue("@wachtwoord", gebruiker.Wachtwoord);
                   // command.Parameters.AddWithValue("@telefoonNummer", gebruiker.TelefoonNummer);
                    //command.Parameters.AddWithValue("@postcode", gebruiker.Postcode);
                    //command.Parameters.AddWithValue("@gemeente", gebruiker.Gemeente);
                   // command.Parameters.AddWithValue("@adresRegel1", gebruiker.AdresRegel1);
                    //command.Parameters.AddWithValue("@adresRegel2", gebruiker.AdresRegel2);
                   // command.Parameters.AddWithValue("@gebruikerId", gebruiker.GebruikerId);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }


        public static Gebruiker GetGebruikerById(int id)
        {
          
            using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
            {
                string query = "SELECT * FROM Gebruikers WHERE GebruikerId = @gebruikerId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@gebruikerId", id);

                
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                   
                    Gebruiker gebruiker = new Gebruiker();
                    gebruiker.GebruikerId = (int)reader["GebruikerId"];
                    gebruiker.Machtiging = (string)reader["Machtiging"];
                    gebruiker.AanmaakDatum = (DateTime)reader["Aanmaakdatum"];
                    gebruiker.VoorNaam = (string)reader["Voornaam"];
                    gebruiker.AchterNaam = (string)reader["Achternaam"];
                    gebruiker.Wachtwoord = (string)reader["Wachtwoord"];
                    gebruiker.TelefoonNummer = (string)reader["TelefoonNummer"];
                    gebruiker.Postcode = (string)reader["Postcode"];
                    gebruiker.Gemeente = (string)reader["Gemeente"];
                    gebruiker.AdresRegel1 = (string)reader["AdresRegel1"];
                    if (reader["AdresRegel2"] != DBNull.Value)
                    {
                        gebruiker.AdresRegel2 = (string)reader["AdresRegel2"];
                    }
                    else
                    {
                        gebruiker.AdresRegel2 = string.Empty;
                    }


                    return gebruiker;
                }

                return null; 
            }
        }

        public static string GetUserEmailFromDatabase(int userId)
        {
            string userEmail = null;

            
            using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
            {
                
                string query = "SELECT Email FROM Gebruikers WHERE GebruikerId = @UserId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                   
                    command.Parameters.AddWithValue("@UserId", userId);

                    
                    connection.Open();

                    
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            
                            userEmail = reader["Email"].ToString();
                        }
                    }
                }
            }

            return userEmail;
        }



        public static Gebruiker GetUserByEmailAndPassword(string email, string password)
        {
            // SqlConnection 
            using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
            {
                // Verifieer de gebruiker met e-mail en wachtwoord
                string query = "SELECT * FROM Gebruikers WHERE Email = @Email AND Wachtwoord = @Password;";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Password", password);
                    connection.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            //Gebruiker heeft gebruikersobject gevonden, gemaakt en geretourneerd
                            Gebruiker user = new Gebruiker();
                            user.GebruikerId = reader["GebruikerId"].GetHashCode();
                            user.Email = reader["Email"].ToString();
                            user.Machtiging = reader["Machtiging"].ToString();
                            user.AanmaakDatum = reader.GetDateTime(reader.GetOrdinal("AanmaakDatum"));
                            user.VoorNaam = reader["Voornaam"].ToString();
                            user.AchterNaam = reader["Achternaam"].ToString();
                            user.Wachtwoord = reader["Wachtwoord"].ToString() ;
                            user.TelefoonNummer = reader["TelefoonNummer"].ToString();
                            user.Postcode = reader["Postcode"].ToString();
                            user.AdresRegel1 = reader["AdresRegel1"].ToString();
                            user.AdresRegel2 = reader["AdresRegel2"].ToString();

                            return user;
                        }
                    }
                }
            }
            return null; 
        }

        public static string GetUserData(string email)
        {
            string userData = "";

            using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
            {
                connection.Open();

                string query = "SELECT GebruikerId, Email, VoorNaam, AchterNaam FROM Gebruikers where Email = @Email;";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Email", email);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userData += reader["GebruikerId"].ToString() + ";";
                            userData += reader["Email"].ToString() + ";";
                            userData += reader["VoorNaam"].ToString() + ";";
                            userData += reader["AchterNaam"].ToString();
                        }
                    }
                }

                connection.Close();
            }
            
            return userData;
        }
        public static string GetUserByEmail(string email)
        {
            using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
            {
                connection.Open();

                var query = "SELECT * FROM Gebruikers WHERE Email = @Email";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", email);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {

                            var user = new Gebruiker();
                            {
                                user.GebruikerId = reader["GebruikerId"].GetHashCode();
                                user.Email = reader["Email"].ToString();
                                user.Machtiging = reader["Machtiging"].ToString();
                                user.AanmaakDatum = reader.GetDateTime(reader.GetOrdinal("AanmaakDatum"));
                                user.VoorNaam = reader["Voornaam"].ToString();
                                user.AchterNaam = reader["Achternaam"].ToString();
                                user.Wachtwoord = reader["Wachtwoord"].ToString();
                                user.TelefoonNummer = reader["TelefoonNummer"].ToString();
                                user.Postcode = reader["Postcode"].ToString();
                                user.AdresRegel1 = reader["AdresRegel1"].ToString();
                                user.AdresRegel2 = reader["AdresRegel2"].ToString();

                                return user.Email;
                            }



                        }
                    }
                }
            }

            return null;
        }

        public static void UpdateUserPassword(int userId, string newPassword)
        {

            using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
            {
                connection.Open();

                string query = "UPDATE Gebruikers SET Wachtwoord = @NewPassword WHERE GebruikerId = @UserId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@NewPassword", newPassword);
                    command.Parameters.AddWithValue("@UserId", userId);

                    command.ExecuteNonQuery();
                }
            }
        }
        public static string GenerateRandomPassword()
        {

            string allowedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

            int passwordLength = 8;


            StringBuilder password = new StringBuilder();


            Random random = new Random();
            while (password.Length < passwordLength)
            {

                char randomChar = allowedChars[random.Next(0, allowedChars.Length)];


                password.Append(randomChar);
            }

            return password.ToString();
        }


        public static void SendPasswordResetEmail(string email, string newPassword)
        {
            
            using (SmtpClient smtpClient = new SmtpClient("smtp.Strato.com", 587))
            {
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new NetworkCredential("depodenopschlagh@wplpxl.be", "WerkpleklerenTeam05");

                using (MailMessage mailMessage = new MailMessage())
                {
                    mailMessage.From = new MailAddress("depodenopschlagh@wplpxl.be");
                    mailMessage.To.Add(new MailAddress(email));
                    mailMessage.Subject = "Verzoek om wachtwoord opnieuw in te stellen";
                    mailMessage.Body = "Nieuwe wachtwoord: " + newPassword;

                    smtpClient.Send(mailMessage);
                }
            }
        }


        public static void CanUserLogIn(string email, string password)
        {
            //Check for valid userinputs
            try
            {
                CheckValidInput(email, password);
                CheckEmailExistence(email);
                CheckPassword(email, password);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private static void CheckValidInput(string email, string password)
        {
            ///Controleert voor de basic inputs.
            /// - Zijn alle gegevens ingevuld?
            /// - Bevat email een [@] en [.]
            /// - Is wachtwoord langer dan 5 characters lang?

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                throw new Exception("Er is geen Email of Wachtwoord ingevuld");
            }
            //Email bevat geen @ of .
            else if (!email.Contains("@") || !email.Contains("."))
            {
                throw new Exception("Email voldoet niet aan de email criteria.");
            }
            //Wachtwoord is korter dan 5 karakters
            else if (password.Length < 5)
            {
                throw new Exception("Systeem heeft geen goesting om wachtwoorden korter dan 5 karakters te controleren. Als uw wachtwoord korter is dan 5 karakters, dan pech 😋");
            }
        }

        public static void CheckEmailExistence(string email)
        {
            // SqlConnection 
            using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
            {

                //Construct SQL Query [Selecteert hoeveel keer het opgegeven email voorkomt]
                string emailQuery = $"SELECT COUNT(*) FROM Gebruikers WHERE Email = @Email";
                SqlCommand command = new SqlCommand(emailQuery, connection);
                command.Parameters.AddWithValue("@Email", email);

                //Voer Query uit
                int count = (int)command.ExecuteScalar();

                //Check
                if (count == 0)
                {
                    throw new Exception($"De opgegeven email [ {email} ] kon niet gevonden worden in de database.");
                }
                //FOUT Als de email 2x voorkomt. [Dit kan niet!]
                else if (count > 1)
                {
                    //De database kan geen 2 dezelfde emails bevatten. DUS ALS DIT VOORKOMT DAN HEBBEN WE EEN GROOT PROBLEEM!!
                    throw new Exception($"De opgegeven email [ {email} ] kwam {count} keer voor in de database.");
                }

            }

        }

        private static void CheckPassword(string email, string password)
        {
            // SqlConnection 
            using (SqlConnection connection = new SqlConnection(Settings.GetConnectionString()))
            {
                //Check als de wachtwoord correct is
                string query = $"SELECT Wachtwoord FROM Gebruikers WHERE Email = @Email;";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", email);

                string correctPassword = (string)command.ExecuteScalar();

                if (String.Compare(password, correctPassword, StringComparison.CurrentCulture) != 0)
                {
                    throw new Exception("Onjuist wachtwoord.");
                }
            }
        }
       
    }
}
