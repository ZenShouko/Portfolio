﻿using ClassLibTeam05.Business;
using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace ClassLibTeam05.Data
{
    internal class HuurPeriodeData : SqlServer
    {
        /// <summary>
        /// Returns a list with all HuurPeriodes related to the given location.
        /// </summary>
        /// <param name="locatieId"></param>
        /// <returns></returns>
        public List<HuurPeriode> GetHuurPeriodes(string locatieId)
        {
            string query = "SELECT ProductId, GebruikerId, VerhuurDatum, RetourDatum, ProductNR FROM HuurPeriode WHERE LocatieId = @locatie;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@locatie", locatieId);
            SelectResult result = Select(cmd);
            List<HuurPeriode> list = new List<HuurPeriode>();

            if (result.Succeeded)
            {
                foreach (DataRow dr in result.DataTable.Rows)
                {
                    HuurPeriode huurPeriode = new HuurPeriode();
                    huurPeriode.LocatieId = locatieId;
                    huurPeriode.ProductId = dr[0].ToString(); /*result.SqlDataReader.GetString(0)*/
                    huurPeriode.GebruikerId = int.Parse(dr[1].ToString());
                    huurPeriode.StartDatum = Convert.ToDateTime(dr[2].ToString()); /*result.SqlDataReader.GetDateTime(2)*/
                    huurPeriode.EindDatum = Convert.ToDateTime(dr[3].ToString()); //result.SqlDataReader.GetDateTime(3)
                    huurPeriode.ProductNR = int.Parse(dr[4].ToString()); // result.SqlDataReader.GetInt32(4);
                    list.Add(huurPeriode);
                }
            }

            return list;
        }

        public DateTime GetFirstRetourDate(string locatieId, string productId)
        {
            string query =
                "SELECT TOP(1) RetourDatum FROM HuurPeriode " +
                "WHERE ProductID = @productID AND LocatieID = @locatieID " +
                "Order by 1;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@productID", productId);
            cmd.Parameters.AddWithValue("@locatieID", locatieId);

            SelectResult result = Select(cmd);
            if (result.Succeeded && result.DataTable.Rows.Count > 0)
            {
                foreach (DataRow dr in result.DataTable.Rows)
                {
                    return Convert.ToDateTime(dr[0].ToString());
                }
            }

            //IF FAIL ==> THROW EXCEPTION |==> ME == ANGRY DEVELOPER >:(
            throw new Exception("No date found");
        }

        public bool CreateOrder(HuurPeriode newOrder)
        {
            //Controle
            if (!CheckOrder(newOrder)) throw new Exception("Order is not valid");

            //Insert as many as the amount
            InsertResult result = null;
            for (int i = 0; i < newOrder.Amount; i++)
            {
                //Insert order
                string query = "INSERT INTO HuurPeriode " +
                    "(ProductID, LocatieID, GebruikerID, VerhuurDatum, RetourDatum, ProductNR) " +
                    "VALUES(@productId, @locatieId, @gebruikerId, @verhuurDatum, @retourDatum, @productNr);";
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@productId", newOrder.ProductId);
                cmd.Parameters.AddWithValue("@locatieId", newOrder.LocatieId);
                cmd.Parameters.AddWithValue("@gebruikerId", newOrder.GebruikerId);
                cmd.Parameters.AddWithValue("@verhuurDatum", newOrder.StartDatum);
                cmd.Parameters.AddWithValue("@retourDatum", newOrder.StartDatum.AddMonths(newOrder.AantalMaanden));
                cmd.Parameters.AddWithValue("@productNr", HuurPeriodes.GetNextGarageNr(newOrder.ProductId, newOrder.LocatieId));

                //cmd.Parameters.AddWithValue("@productNr", HuurPeriodes.GetNextGarageNr(newOrder.ProductId, newOrder.LocatieId) + i);
                
                // DOE!!
                result = Insert(cmd);

                // FOUT??
                if (!result.Succeeded)
                {
                    throw new Exception(result.Errors.ToString()); //Onder anderen
                }
            }
            
            return result.Succeeded;
        }

        private static bool CheckOrder(HuurPeriode orderInQuestion)
        {
            if (!Producten.CheckProductId(orderInQuestion.ProductId) || !ParkLocaties.DoesLocationExist(orderInQuestion.LocatieId) ||
                orderInQuestion.GebruikerId < 1 || orderInQuestion.StartDatum < DateTime.Now ||
                orderInQuestion.AantalMaanden < 1)
            {
                return false;
            }

            return true;
        }

        public int GetNextGarageNr(string locatieId, string productId)
        {
            //Counts the records with the same productID and locationID and adds 1
            string query = "SELECT COUNT(*) FROM HuurPeriode WHERE ProductID = @productID AND LocatieID = @locatieID;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@productID", productId);
            cmd.Parameters.AddWithValue("@locatieID", locatieId);

            SelectResult result = Select(cmd);
            if (result.Succeeded)
            {
                foreach (DataRow row in result.DataTable.Rows)
                {
                    return Convert.ToInt32(row[0]) + 1;
                }
            }

            //IF FAIL ==> THROW EXCEPTION |==> ME == ANGRY DEVELOPER >:(
            throw new Exception("Er is een fout opgetreden bij het ophalen van het volgende garage nummer.");
        }
    }
}
