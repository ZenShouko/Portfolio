﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Data
{
    internal class ProductPrijsData : SqlServer
    {
        public List<ProductPrijs> GetGaragePrijzen()
        {
            //Query & SqlCommand
            string query = "Select * From Prijzen;";
            SqlCommand cmd = new SqlCommand(query);

            //List v/d type ParkLocatie
            List<ProductPrijs> prijzenLijst = new List<ProductPrijs>();

            SelectResult result = Select(cmd);
            if (result.Succeeded)
            {
                foreach (DataRow row in result.DataTable.Rows)
                {
                    ProductPrijs prijs = new ProductPrijs();
                    prijs.ProductID = row[0].ToString();
                    prijs.Huurprijs = int.Parse(row[1].ToString());
                    prijs.ServiceKosten = int.Parse(row[2].ToString());
                    prijs.EnergieKosten = int.Parse(row[3].ToString());
                    prijs.Waarborg = int.Parse(row[4].ToString());
                    prijs.AdministratieKosten = int.Parse(row[5].ToString());
                    prijs.Grootte = row[6].ToString();
                    prijzenLijst.Add(prijs);
                }
            }

            return prijzenLijst;
        }
    }
}
