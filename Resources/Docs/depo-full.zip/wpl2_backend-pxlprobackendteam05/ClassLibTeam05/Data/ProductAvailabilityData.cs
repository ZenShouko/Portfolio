﻿using ClassLibTeam05.Business;
using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data.Framework;
using System;
using System.Collections.Generic;

namespace ClassLibTeam05.Data
{
    internal class ProductAvailabilityData : SqlServer
    {
        public List<ProductAvailability> GetAvailabilities(string ID)
        {
            //Get Capacity
            LocatieCapaciteit capaciteit = LocatieCapaciteiten.GetSizesBasedOnLocation(ID);
            //Check if the capacity is not null
            if (capaciteit.XS == 0 && capaciteit.S == 0 && capaciteit.M == 0 && capaciteit.L == 0)
                return null;

            //Get InUse
            LocatieCapaciteit inGebruik = LocatieCapaciteiten.GetInUseBasedOnLocation(ID);

            //Add all available products to the list
            List<ProductAvailability> list = new List<ProductAvailability>();
            if (capaciteit.XS > inGebruik.XS)
            {
                ProductAvailability pa = new ProductAvailability();
                pa.LocationId = ID;
                pa.ProductId = "GRG12";
                pa.Size = "12m2";
                pa.IsAvailable = true;
                pa.AvailableDate = DateTime.Today.AddDays(1).Date;
                pa.Amount = capaciteit.XS - inGebruik.XS;
                list.Add(pa);
            }
            else if (capaciteit.XS > 0)
            {
                ProductAvailability pa = new ProductAvailability();
                pa.LocationId = ID;
                pa.ProductId = "GRG12";
                pa.Size = "12m2";
                pa.IsAvailable = false;
                pa.AvailableDate = HuurPeriodes.GetFirstRetourDate(ID, "GRG12");
                pa.Amount = 0;
                list.Add(pa);
            }

            if (capaciteit.S > inGebruik.S)
            {
                ProductAvailability pa = new ProductAvailability();
                pa.LocationId = ID;
                pa.ProductId = "GRG18";
                pa.Size = "18m2";
                pa.IsAvailable = true;
                pa.AvailableDate = DateTime.Today.AddDays(1).Date;
                pa.Amount = capaciteit.S - inGebruik.S;
                list.Add(pa);
            }
            else if (capaciteit.S > 0)
            {
                ProductAvailability pa = new ProductAvailability();
                pa.LocationId = ID;
                pa.ProductId = "GRG18";
                pa.Size = "18m2";
                pa.IsAvailable = false;
                pa.AvailableDate = HuurPeriodes.GetFirstRetourDate(ID, "GRG18");
                pa.Amount = 0;
                list.Add(pa);
            }

            if (capaciteit.M > inGebruik.M)
            {
                ProductAvailability pa = new ProductAvailability();
                pa.LocationId = ID;
                pa.ProductId = "GRG24";
                pa.Size = "24m2";
                pa.IsAvailable = true;
                pa.AvailableDate = DateTime.Today.AddDays(1).Date;
                pa.Amount = capaciteit.M - inGebruik.M;
                list.Add(pa);
            }
            else if (capaciteit.M > 0)
            {
                ProductAvailability pa = new ProductAvailability();
                pa.LocationId = ID;
                pa.ProductId = "GRG24";
                pa.Size = "24m2";
                pa.IsAvailable = false;
                pa.AvailableDate = HuurPeriodes.GetFirstRetourDate(ID, "GRG24");
                pa.Amount = 0;
                list.Add(pa);
            }

            if (capaciteit.L > inGebruik.L)
            {
                ProductAvailability pa = new ProductAvailability();
                pa.LocationId = ID;
                pa.ProductId = "GRG36";
                pa.Size = "36m2";
                pa.IsAvailable = true;
                pa.AvailableDate = DateTime.Today.AddDays(1).Date;
                pa.Amount = capaciteit.L - inGebruik.L;
                list.Add(pa);
            }
            else if (capaciteit.L > 0)
            {
                ProductAvailability pa = new ProductAvailability();
                pa.LocationId = ID;
                pa.ProductId = "GRG36";
                pa.Size = "36m2";
                pa.IsAvailable = false;
                pa.AvailableDate = HuurPeriodes.GetFirstRetourDate(ID, "GRG36");
                pa.Amount = 0;
                list.Add(pa);
            }

            return list;
        }
    }
}
