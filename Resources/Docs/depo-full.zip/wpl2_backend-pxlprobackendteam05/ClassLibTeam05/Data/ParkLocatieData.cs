﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Data
{
    internal class ParkLocatieData : SqlServer
    {
        public List<ParkLocatie> GetAll()
        {
            //Query & SqlCommand
            string query = "Select LocatieID, Postcode, Gemeente From GpLocatie;";
            SqlCommand cmd = new SqlCommand(query);

            //List v/d type ParkLocatie
            List<ParkLocatie> locaties = new List<ParkLocatie>();

            SelectResult result = Select(cmd);

            if (result.Succeeded)
            {
                foreach (DataRow dr in result.DataTable.Rows)
                {
                    ParkLocatie locatie = new ParkLocatie();
                    locatie.LocatieId = dr[0].ToString();
                    locatie.Postcode = int.Parse(dr[1].ToString());
                    locatie.Gemeente = dr[2].ToString();
                    locaties.Add(locatie);
                }
            }

            return locaties;
        }

        /// <summary>
        /// Gets all the locationID's from a specific gemeente
        /// </summary>
        /// <param name="gemeente"></param>
        /// <returns></returns>
        public List<string> GetLocationIDs(string gemeente)
        {
            string query = "SELECT LocatieID FROM GpLocatie WHERE Gemeente = @gemeente;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@gemeente", gemeente);
            SelectResult result = Select(cmd);

            if (result.Succeeded)
            {
                List<string> locatieIDs = new List<string>();
                foreach (DataRow dr in result.DataTable.Rows)
                {
                    locatieIDs.Add(dr[0].ToString());
                }
                return locatieIDs;
            }
            else
            {
                throw new Exception("Er zijn geen locatieID's gevonden voor de gemeente: " + gemeente);
            }
        }

        public bool CheckGemeentesExistance(string gemeente)
        {
            string query = "SELECT TOP(1) * FROM GpLocatie WHERE Gemeente = @gemeente;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@gemeente", gemeente);

            SelectResult result = Select(cmd);
            if (result.Succeeded)
            {
                if (result.DataTable.Rows.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new Exception("Er is iets fout gegaan bij het ophalen van de gemeentes.");
            }
        }

        public bool CheckLocatieExistance(string ID)
        {
            string query = "SELECT TOP(1) * FROM GpLocatie WHERE LocatieID = @ID;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@ID", ID);
            SelectResult result = Select(cmd);
            if (result.Succeeded)
            {
                if (result.DataTable.Rows.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new Exception("Er is iets fout gegaan bij het ophalen van de gemeentes.");
            }
        }

        public int GetCountGemeente(string gemeente)
        {
            string query = "SELECT COUNT(*) FROM GpLocatie WHERE Gemeente = @gemeente;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@gemeente", gemeente);
            SelectResult result = Select(cmd);
            if (result.Succeeded)
            {
                return int.Parse(result.DataTable.Rows[0][0].ToString());
            }
            else
            {
                throw new Exception("Er is iets fout gegaan bij het ophalen van de gemeentes.");
            }
        }

        public void AddParkLocatie(string gemeente, int postcode)
        {
            string query = "INSERT INTO Locaties (Postcode, Gemeente) VALUES (@postcode, @gemeente);";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@postcode", postcode);
            cmd.Parameters.AddWithValue("@gemeente", gemeente);
            InsertResult result = Insert(cmd);

            if (!result.Succeeded)
            {
                throw new Exception(result.Errors.ToString());
            }
        }
    }
}
