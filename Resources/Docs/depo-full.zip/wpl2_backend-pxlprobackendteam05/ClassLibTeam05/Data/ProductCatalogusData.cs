﻿using ClassLibTeam05.Business;
using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data.Framework;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace ClassLibTeam05.Data
{
    internal class ProductCatalogusData : SqlServer
    {
        public List<ProductCatalogus> GetAll(string gemeente)
        {
            //Get all the locatieID's
            List<string> locatieIDs = ParkLocaties.GetAllLocationIDs(gemeente);

            //Create a list of ProductCatalogus
            List<ProductCatalogus> list = new List<ProductCatalogus>();

            //Query & SqlCommand
            string query = "SELECT Gemeente, AdresRegel, RegionalePrijs, Postcode FROM GpLocatie WHERE LocatieId = @LocatieID;";

            //Loop through all the locatieID's
            foreach (string id in locatieIDs)
            {
                //Create a new ProductCatalogus based on the locatieID
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@LocatieID", id);

                SelectResult result = Select(cmd);
                if (result.Succeeded)
                {
                    foreach (DataRow dr in result.DataTable.Rows)
                    {
                        ProductCatalogus product = new ProductCatalogus();
                        product.LocatieId = id;
                        product.Gemeente = dr[0].ToString();
                        product.Adres = dr[1].ToString();
                        product.RegionalePrijs = int.Parse(dr[2].ToString());
                        product.Postcode = int.Parse(dr[3].ToString());
                        list.Add(product);
                    }
                }
            }

            //Loop again but now add product Images
            foreach (ProductCatalogus product in list)
            {
                //Query & SqlCommand
                query = "SELECT ImageName FROM ProductImage WHERE LocatieID = @LocatieID;";
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@LocatieID", product.LocatieId);

                SelectResult result = Select(cmd);
                if (result.Succeeded)
                {
                    List<string> imageNames = new List<string>();
                    foreach (DataRow dr in result.DataTable.Rows)
                    {
                        imageNames.Add(dr[0].ToString());
                    }
                    product.ListImageNames = imageNames;
                }
            }

            return list;
        }
    }
}
