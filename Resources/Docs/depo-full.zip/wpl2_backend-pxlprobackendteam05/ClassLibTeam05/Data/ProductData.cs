﻿using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data.Framework;
using System.Data;
using System.Data.SqlClient;

namespace ClassLibTeam05.Data
{
    internal class ProductData : SqlServer
    {
        /// <summary>
        /// { "Size", "SizeName", "ProductID" }
        /// </summary>
        private string[,] productDefinitions = new string[,]
            {
                {"12m2", "XS", "GRG12"},
                {"18m2", "S", "GRG18"},
                {"24m2", "M", "GRG24"},
                {"36m2", "L", "GRG36"}
            };

        public Product GetOmschrijving(Product prod)
        {
            //Determine productID based on size
            for (int i = 0; i < productDefinitions.GetLength(0); i++)
            {
                if (productDefinitions[i, 0] == prod.Size)
                {
                    prod.ProductId = productDefinitions[i, 2];
                    break;
                }
            }

            //Get the omschrijving
            string query = "SELECT ArtikelOmschrijving FROM Producten WHERE ProductID = @ProductID;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@ProductID", prod.ProductId);
            SelectResult result = Select(cmd);

            if (result.Succeeded)
            {
                foreach (DataRow row in result.DataTable.Rows)
                {
                    prod.Omschrijving = row[0].ToString();
                }
            }
            else
            {
                System.Console.WriteLine($"Couldn't find ArtikelOmschrijving for the ID: [{prod.ProductId}]");
                return null;
            }

            return prod;
        }

        public bool CheckProductId(string id)
        {
            //Check if the productID exists
            string query = "SELECT COUNT(*) FROM Producten WHERE ProductID = @ProductID;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@ProductID", id);
            SelectResult result = Select(cmd);
            if (result.Succeeded)
            {
                foreach (DataRow row in result.DataTable.Rows)
                {
                    int amount = int.Parse(row[0].ToString());
                    if (amount > 0)
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}
