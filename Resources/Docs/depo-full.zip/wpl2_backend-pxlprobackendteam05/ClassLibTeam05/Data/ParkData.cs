﻿using ClassLibTeam05.Business;
using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace ClassLibTeam05.Data
{
    internal class ParkData : SqlServer
    {
        public static void AddPark(Park park)
        {
            ParkData pd = new ParkData();
            //[1] Update Locaties tabel
            if (!ParkLocaties.DoesGemeenteExist(park.Gemeente))
            {
                //Update Locaties table
                ParkLocaties.AddParkLocatie(park.Gemeente, park.Postcode);
            }

            //[2] Update GpLocatie tabel
            pd.InsertGpLocatie(park);

            //[3] Update LocatieCapaciteit tabel
            pd.InsertLocatieCapaciteit(park);

            //[4] Update ProductImage tabel
            pd.InsertProductImage(park);
        }

        private void InsertGpLocatie(Park park)
        {
            string query = "INSERT INTO GpLocatie " +
                "(LocatieId, Gemeente, Postcode, AdresRegel, RegionalePrijs) " +
                "VALUES(@locatieID, @gemeente, @postcode, @adresRegel, @regionalePrijs);";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@locatieID", park.LocatieId);
            cmd.Parameters.AddWithValue("@gemeente", park.Gemeente);
            cmd.Parameters.AddWithValue("@postcode", park.Postcode);
            cmd.Parameters.AddWithValue("@adresRegel", park.Adres);
            cmd.Parameters.AddWithValue("@regionalePrijs", park.RegionalePrijs);

            InsertResult result = Insert(cmd);
            if (!result.Succeeded)
            {
                throw new Exception(result.Errors.ToString());
            }
        }

        private void InsertLocatieCapaciteit(Park park)
        {
            string query = "INSERT INTO LocatieCapaciteit " +
                "(LocatieId, XS, S, M, L) " +
                "VALUES(@locatieID, @XS, @S, @M, @L);";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@locatieID", park.LocatieId);
            cmd.Parameters.AddWithValue("@XS", park.XS);
            cmd.Parameters.AddWithValue("@S", park.S);
            cmd.Parameters.AddWithValue("@M", park.M);
            cmd.Parameters.AddWithValue("@L", park.L);

            InsertResult result = Insert(cmd);
            if (!result.Succeeded)
            {
                throw new Exception(result.Errors.ToString());
            }
        }

        private void InsertProductImage(Park park)
        {
            string query = "INSERT INTO ProductImage " +
                "(LocatieId, ImageName) " +
                "VALUES(@locatieID, @ImageName);";

            //Iterate over images
            park.ImageNames.ForEach(imageName =>
            {
                //Modify imageName, remove ".jpg"
                imageName = imageName.Replace(".jpg", "");

                //Insert into ProductImage table
                SqlCommand cmd = new SqlCommand(query);
                cmd.Parameters.AddWithValue("@locatieID", park.LocatieId);
                cmd.Parameters.AddWithValue("@ImageName", imageName);

                //Execute query
                InsertResult result = Insert(cmd);
                if (!result.Succeeded)
                {
                    throw new Exception(result.Errors.ToString());
                }
            });
        }

        public static void Modify(List<SqlCommand> commands)
        {
            ParkData pd = new ParkData();
            foreach (SqlCommand cmd in commands)
            {
                pd.ExecuteCmd(cmd);
            }
        }

        private void ExecuteCmd(SqlCommand cmd)
        {
            InsertResult result = Insert(cmd);
            if (!result.Succeeded)
            {
                throw new Exception(result.Errors.ToString());
            }
        }
    }
}
