﻿using ClassLibTeam05.Business;
using ClassLibTeam05.Business.Entities;
using ClassLibTeam05.Data.Framework;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam05.Data
{
    internal class LocatieCapaciteitData : SqlServer
    {
        /// <summary>
        /// Totaalcapaciteit van een gemeente
        /// </summary>
        /// <param name="gemeente"></param>
        /// <returns></returns>
        public LocatieCapaciteit GetSumSizes(string gemeente)
        {
            //List with all the ID's from the gemeente
            List<string> IDs = ParkLocaties.GetAllLocationIDs(gemeente);

            //List to keep track of all the LocatieCapaciteit objects
            List<LocatieCapaciteit> locatieCapaciteiten = new List<LocatieCapaciteit>();
            foreach (var id in IDs)
            {
                locatieCapaciteiten.Add(CreateNewLocatieCapaciteit(id));
            }

            //Create a new LocatieCapaciteit object and keep count of the total capacity
            LocatieCapaciteit totaalCapaciteit = new LocatieCapaciteit();
            foreach (var item in locatieCapaciteiten)
            {
                totaalCapaciteit.XS += item.XS;
                totaalCapaciteit.S += item.S;
                totaalCapaciteit.M += item.M;
                totaalCapaciteit.L += item.L;
            }

            return totaalCapaciteit;
        }


        /// <summary>
        /// Returns a LocatieCapaciteit object based on the LocatieID
        /// </summary>
        /// <param name="LocatieID"></param>
        /// <returns></returns>
        public LocatieCapaciteit CreateNewLocatieCapaciteit(string LocatieID)
        {
            LocatieCapaciteit lc = new LocatieCapaciteit();
            //Assign the LocatieID
            lc.LocatieId = LocatieID;

            //Get the capacity from the database
            string query = "Select XS, S, M, L From LocatieCapaciteit Where LocatieID = @LocatieID;";
            SqlCommand cmd = new SqlCommand(query);
            cmd.Parameters.AddWithValue("@LocatieID", LocatieID);
            SelectResult result = Select(cmd);

            if (result.Succeeded)
            {
                foreach (DataRow row in result.DataTable.Rows)
                {
                    lc.XS = int.Parse(row[0].ToString());
                    lc.S = int.Parse(row[1].ToString());
                    lc.M = int.Parse(row[2].ToString());
                    lc.L = int.Parse(row[3].ToString());
                }
            }

            return lc;
        }

        /// <summary>
        /// Counts all products that are in use on a specific location
        /// </summary>
        /// <param name="LocatieID"></param>
        /// <returns></returns>
        public LocatieCapaciteit CreateNewInUseCapaciteit(string LocatieID)
        {
            //Get Huurperiodes
            List<HuurPeriode> list = HuurPeriodes.GetHuurPeriodes(LocatieID);
            //New model
            LocatieCapaciteit inGebruik = new LocatieCapaciteit();

            //Cycle throuw the list and count the sizes
            foreach(var item in list)
            {
                switch (item.ProductId)
                {
                    case "GRG12":
                        {
                            inGebruik.XS++;
                            break;
                        }
                    case "GRG18":
                        {
                            inGebruik.S++;
                            break;
                        }
                    case "GRG24":
                        {
                            inGebruik.M++;
                            break;
                        }
                    case "GRG36":
                        {
                            inGebruik.L++;
                            break;
                        }
                }
            }

            return inGebruik;
        }
    }
}
