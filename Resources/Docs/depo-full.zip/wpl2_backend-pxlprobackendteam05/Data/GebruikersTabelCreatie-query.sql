--***[NIET UITVOEREN, DIENT ALLEEN TER REFERENTIE]***--

create table Gebruikers
(
	GebruikerId int identity(1, 1) NOT NULL Primary Key,
	Machtiging varchar(12) NOT NULL,
	AanmaakDatum Date NOT NULL,
	Email varchar(100) NOT NULL,
	VoorNaam varchar(30) NOT NULL,
	AchterNaam varchar(30) NOT NULL,
	Wachtwoord varchar(50) NOT NULL,
	TelefoonNummer varchar(20) NOT NULL,
	Postcode varchar(12) NOT NULL,
	Gemeente varchar(50) NOT NULL,
	AdresRegel1 varchar(100) NOT NULL,
	AdresRegel2 varchar(100)
);

Create Table Locaties
(
	Postcode varchar(12) Primary Key NOT NULL,
	Gemeente varchar(50) NOT NULL
);